"""
نظام البحث التطوري SpokForNAS للنظام الموحد
SpokForNAS Evolutionary Search System for Unified System

يتضمن:
- البحث عن بنية الشبكات العصبية
- نقل الخبرة بين التجارب
- تحسين معدل التعلم التكيفي
- معالجة الأخطاء الذكية
"""

import sys
sys.path.append('/home/ubuntu/unified_ai_system')

import numpy as np
import random
import json
import time
from typing import List, Dict, Any, Tuple, Optional, Callable
from dataclasses import dataclass, asdict
from abc import ABC, abstractmethod
import logging

from core.autodiff.node_fixed import Node, tensor
from core.autodiff.layers import Sequential, Linear, ReLU, Sigmoid, Tanh, Dropout, BatchNorm1d
from core.autodiff.optimizers import Adam, SGD

# إعداد نظام السجلات
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class NetworkArchitecture:
    """تمثيل بنية الشبكة العصبية"""
    layers: List[Dict[str, Any]]
    input_size: int
    output_size: int
    activation_functions: List[str]
    dropout_rates: List[float]
    use_batch_norm: List[bool]
    
    def to_dict(self) -> Dict[str, Any]:
        """تحويل إلى قاموس"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NetworkArchitecture':
        """إنشاء من قاموس"""
        return cls(**data)
    
    def get_complexity_score(self) -> float:
        """حساب درجة تعقد الشبكة"""
        total_params = 0
        prev_size = self.input_size
        
        for layer in self.layers:
            if layer['type'] == 'linear':
                current_size = layer['size']
                total_params += prev_size * current_size + current_size  # weights + bias
                prev_size = current_size
        
        # إضافة معاملات الخرج
        total_params += prev_size * self.output_size + self.output_size
        
        return total_params

@dataclass
class Individual:
    """فرد في المجتمع التطوري"""
    architecture: NetworkArchitecture
    fitness: float = 0.0
    age: int = 0
    parent_ids: List[str] = None
    mutation_history: List[str] = None
    
    def __post_init__(self):
        if self.parent_ids is None:
            self.parent_ids = []
        if self.mutation_history is None:
            self.mutation_history = []
    
    @property
    def id(self) -> str:
        """معرف فريد للفرد"""
        return f"ind_{hash(str(self.architecture.to_dict()))}"

class FitnessEvaluator(ABC):
    """مقيم اللياقة المجرد"""
    
    @abstractmethod
    def evaluate(self, architecture: NetworkArchitecture, 
                 train_data: Tuple[np.ndarray, np.ndarray],
                 val_data: Tuple[np.ndarray, np.ndarray]) -> float:
        """تقييم لياقة البنية"""
        pass

class QuickFitnessEvaluator(FitnessEvaluator):
    """مقيم لياقة سريع للاختبار"""
    
    def __init__(self, max_epochs: int = 10, early_stopping: int = 3):
        self.max_epochs = max_epochs
        self.early_stopping = early_stopping
    
    def evaluate(self, architecture: NetworkArchitecture, 
                 train_data: Tuple[np.ndarray, np.ndarray],
                 val_data: Tuple[np.ndarray, np.ndarray]) -> float:
        """تقييم سريع للبنية"""
        try:
            # بناء النموذج
            model = self._build_model(architecture)
            
            # تحضير البيانات
            X_train, y_train = train_data
            X_val, y_val = val_data
            
            # تدريب سريع
            optimizer = Adam(model.get_parameters(), lr=0.01)
            best_val_acc = 0.0
            patience_counter = 0
            
            for epoch in range(self.max_epochs):
                # تدريب
                model.train()
                train_loss = self._train_epoch(model, optimizer, X_train, y_train)
                
                # تقييم
                model.eval()
                val_acc = self._evaluate_accuracy(model, X_val, y_val)
                
                # Early stopping
                if val_acc > best_val_acc:
                    best_val_acc = val_acc
                    patience_counter = 0
                else:
                    patience_counter += 1
                    if patience_counter >= self.early_stopping:
                        break
            
            # حساب اللياقة (دقة - معقدة)
            complexity_penalty = architecture.get_complexity_score() / 100000.0
            fitness = best_val_acc - 0.1 * complexity_penalty
            
            return max(0.0, fitness)
            
        except Exception as e:
            logger.warning(f"خطأ في تقييم البنية: {e}")
            return 0.0
    
    def _build_model(self, architecture: NetworkArchitecture) -> Sequential:
        """بناء النموذج من البنية"""
        layers = []
        prev_size = architecture.input_size
        
        for i, layer_config in enumerate(architecture.layers):
            if layer_config['type'] == 'linear':
                current_size = layer_config['size']
                layers.append(Linear(prev_size, current_size))
                
                # إضافة batch normalization
                if i < len(architecture.use_batch_norm) and architecture.use_batch_norm[i]:
                    layers.append(BatchNorm1d(current_size))
                
                # إضافة دالة التفعيل
                if i < len(architecture.activation_functions):
                    activation = architecture.activation_functions[i]
                    if activation == 'relu':
                        layers.append(ReLU())
                    elif activation == 'sigmoid':
                        layers.append(Sigmoid())
                    elif activation == 'tanh':
                        layers.append(Tanh())
                
                # إضافة dropout
                if i < len(architecture.dropout_rates) and architecture.dropout_rates[i] > 0:
                    layers.append(Dropout(architecture.dropout_rates[i]))
                
                prev_size = current_size
        
        # طبقة الخرج
        layers.append(Linear(prev_size, architecture.output_size))
        layers.append(Sigmoid())  # للتصنيف
        
        return Sequential(*layers)
    
    def _train_epoch(self, model: Sequential, optimizer, X: np.ndarray, y: np.ndarray) -> float:
        """تدريب عصر واحد"""
        batch_size = min(32, len(X))
        total_loss = 0.0
        num_batches = 0
        
        for i in range(0, len(X), batch_size):
            end_i = min(i + batch_size, len(X))
            X_batch = tensor(X[i:end_i], requires_grad=False)
            y_batch = tensor(y[i:end_i], requires_grad=False)
            
            optimizer.zero_grad()
            
            pred = model(X_batch)
            loss = ((pred - y_batch) ** 2).mean()
            
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            num_batches += 1
        
        return total_loss / num_batches
    
    def _evaluate_accuracy(self, model: Sequential, X: np.ndarray, y: np.ndarray) -> float:
        """تقييم الدقة"""
        X_tensor = tensor(X, requires_grad=False)
        y_tensor = tensor(y, requires_grad=False)
        
        pred = model(X_tensor)
        
        # حساب الدقة للتصنيف
        pred_classes = np.argmax(pred.data, axis=1)
        true_classes = np.argmax(y_tensor.data, axis=1)
        
        return np.mean(pred_classes == true_classes)

class ArchitectureMutator:
    """مطفر البنى المعمارية"""
    
    def __init__(self, mutation_rate: float = 0.1):
        self.mutation_rate = mutation_rate
        self.available_activations = ['relu', 'sigmoid', 'tanh']
    
    def mutate(self, architecture: NetworkArchitecture) -> NetworkArchitecture:
        """تطفير البنية"""
        new_arch = NetworkArchitecture(
            layers=architecture.layers.copy(),
            input_size=architecture.input_size,
            output_size=architecture.output_size,
            activation_functions=architecture.activation_functions.copy(),
            dropout_rates=architecture.dropout_rates.copy(),
            use_batch_norm=architecture.use_batch_norm.copy()
        )
        
        mutations_applied = []
        
        # تطفير أحجام الطبقات
        if random.random() < self.mutation_rate:
            layer_idx = random.randint(0, len(new_arch.layers) - 1)
            old_size = new_arch.layers[layer_idx]['size']
            # تغيير الحجم بنسبة ±50%
            factor = random.uniform(0.5, 1.5)
            new_size = max(8, min(512, int(old_size * factor)))
            new_arch.layers[layer_idx]['size'] = new_size
            mutations_applied.append(f"layer_{layer_idx}_size_{old_size}_to_{new_size}")
        
        # تطفير دوال التفعيل
        if random.random() < self.mutation_rate:
            if new_arch.activation_functions:
                idx = random.randint(0, len(new_arch.activation_functions) - 1)
                old_activation = new_arch.activation_functions[idx]
                new_activation = random.choice(self.available_activations)
                new_arch.activation_functions[idx] = new_activation
                mutations_applied.append(f"activation_{idx}_{old_activation}_to_{new_activation}")
        
        # تطفير معدلات dropout
        if random.random() < self.mutation_rate:
            if new_arch.dropout_rates:
                idx = random.randint(0, len(new_arch.dropout_rates) - 1)
                old_rate = new_arch.dropout_rates[idx]
                new_rate = max(0.0, min(0.5, old_rate + random.uniform(-0.1, 0.1)))
                new_arch.dropout_rates[idx] = new_rate
                mutations_applied.append(f"dropout_{idx}_{old_rate:.2f}_to_{new_rate:.2f}")
        
        # تطفير batch normalization
        if random.random() < self.mutation_rate:
            if new_arch.use_batch_norm:
                idx = random.randint(0, len(new_arch.use_batch_norm) - 1)
                new_arch.use_batch_norm[idx] = not new_arch.use_batch_norm[idx]
                mutations_applied.append(f"batch_norm_{idx}_toggled")
        
        # إضافة أو حذف طبقة
        if random.random() < self.mutation_rate * 0.5:  # احتمالية أقل
            if len(new_arch.layers) < 5 and random.random() < 0.5:
                # إضافة طبقة
                insert_idx = random.randint(0, len(new_arch.layers))
                new_size = random.randint(16, 128)
                new_layer = {'type': 'linear', 'size': new_size}
                new_arch.layers.insert(insert_idx, new_layer)
                
                # إضافة خصائص مقابلة
                new_arch.activation_functions.insert(insert_idx, random.choice(self.available_activations))
                new_arch.dropout_rates.insert(insert_idx, random.uniform(0.0, 0.3))
                new_arch.use_batch_norm.insert(insert_idx, random.choice([True, False]))
                
                mutations_applied.append(f"added_layer_{insert_idx}_size_{new_size}")
            
            elif len(new_arch.layers) > 1 and random.random() >= 0.5:
                # حذف طبقة
                remove_idx = random.randint(0, len(new_arch.layers) - 1)
                removed_layer = new_arch.layers.pop(remove_idx)
                
                # حذف الخصائص المقابلة
                if remove_idx < len(new_arch.activation_functions):
                    new_arch.activation_functions.pop(remove_idx)
                if remove_idx < len(new_arch.dropout_rates):
                    new_arch.dropout_rates.pop(remove_idx)
                if remove_idx < len(new_arch.use_batch_norm):
                    new_arch.use_batch_norm.pop(remove_idx)
                
                mutations_applied.append(f"removed_layer_{remove_idx}_size_{removed_layer['size']}")
        
        return new_arch

class ArchitectureCrossover:
    """مزج البنى المعمارية"""
    
    def crossover(self, parent1: NetworkArchitecture, parent2: NetworkArchitecture) -> Tuple[NetworkArchitecture, NetworkArchitecture]:
        """مزج بنيتين لإنتاج بنيتين جديدتين"""
        
        # اختيار نقطة القطع
        min_layers = min(len(parent1.layers), len(parent2.layers))
        if min_layers <= 1:
            return parent1, parent2
        
        crossover_point = random.randint(1, min_layers - 1)
        
        # إنشاء الأطفال
        child1_layers = parent1.layers[:crossover_point] + parent2.layers[crossover_point:]
        child2_layers = parent2.layers[:crossover_point] + parent1.layers[crossover_point:]
        
        # مزج الخصائص الأخرى
        child1_activations = parent1.activation_functions[:crossover_point] + parent2.activation_functions[crossover_point:]
        child2_activations = parent2.activation_functions[:crossover_point] + parent1.activation_functions[crossover_point:]
        
        child1_dropout = parent1.dropout_rates[:crossover_point] + parent2.dropout_rates[crossover_point:]
        child2_dropout = parent2.dropout_rates[:crossover_point] + parent1.dropout_rates[crossover_point:]
        
        child1_bn = parent1.use_batch_norm[:crossover_point] + parent2.use_batch_norm[crossover_point:]
        child2_bn = parent2.use_batch_norm[:crossover_point] + parent1.use_batch_norm[crossover_point:]
        
        # إنشاء البنى الجديدة
        child1 = NetworkArchitecture(
            layers=child1_layers,
            input_size=parent1.input_size,
            output_size=parent1.output_size,
            activation_functions=child1_activations,
            dropout_rates=child1_dropout,
            use_batch_norm=child1_bn
        )
        
        child2 = NetworkArchitecture(
            layers=child2_layers,
            input_size=parent2.input_size,
            output_size=parent2.output_size,
            activation_functions=child2_activations,
            dropout_rates=child2_dropout,
            use_batch_norm=child2_bn
        )
        
        return child1, child2

class SpokForNAS:
    """نظام البحث التطوري SpokForNAS الرئيسي"""
    
    def __init__(self, 
                 population_size: int = 20,
                 elite_size: int = 5,
                 mutation_rate: float = 0.1,
                 crossover_rate: float = 0.7,
                 max_generations: int = 50,
                 input_size: int = 784,
                 output_size: int = 10):
        
        self.population_size = population_size
        self.elite_size = elite_size
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.max_generations = max_generations
        self.input_size = input_size
        self.output_size = output_size
        
        # مكونات النظام
        self.fitness_evaluator = QuickFitnessEvaluator()
        self.mutator = ArchitectureMutator(mutation_rate)
        self.crossover = ArchitectureCrossover()
        
        # حالة النظام
        self.population: List[Individual] = []
        self.generation = 0
        self.best_individual: Optional[Individual] = None
        self.history: List[Dict[str, Any]] = []
        
        logger.info(f"تم تهيئة SpokForNAS: population={population_size}, generations={max_generations}")
    
    def initialize_population(self) -> None:
        """تهيئة المجتمع الأولي"""
        self.population = []
        
        for i in range(self.population_size):
            # توليد بنية عشوائية
            num_layers = random.randint(2, 4)
            layers = []
            activations = []
            dropout_rates = []
            use_batch_norm = []
            
            for j in range(num_layers):
                layer_size = random.randint(32, 256)
                layers.append({'type': 'linear', 'size': layer_size})
                activations.append(random.choice(['relu', 'sigmoid', 'tanh']))
                dropout_rates.append(random.uniform(0.0, 0.3))
                use_batch_norm.append(random.choice([True, False]))
            
            architecture = NetworkArchitecture(
                layers=layers,
                input_size=self.input_size,
                output_size=self.output_size,
                activation_functions=activations,
                dropout_rates=dropout_rates,
                use_batch_norm=use_batch_norm
            )
            
            individual = Individual(architecture=architecture)
            self.population.append(individual)
        
        logger.info(f"تم تهيئة مجتمع من {len(self
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)