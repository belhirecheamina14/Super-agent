"""
مثال تدريب شامل لشبكة عصبية على بيانات MNIST المحاكاة
Complete Neural Network Training Example on Simulated MNIST Data

يوضح:
- تحضير البيانات
- بناء النموذج
- حلقة التدريب
- التقييم
- حفظ النموذج
"""

import sys
sys.path.append('/home/ubuntu/unified_ai_system')

import numpy as np
from typing import Tuple, List
import time
import matplotlib.pyplot as plt

from core.autodiff.node_fixed import Node, tensor, randn, zeros
from core.autodiff.layers import Sequential, Linear, ReLU, Sigmoid, Dropout, BatchNorm1d
from core.autodiff.optimizers import Adam, SGD, StepLR
import logging

# إعداد نظام السجلات
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MNISTSimulator:
    """محاكي بيانات MNIST للاختبار"""
    
    def __init__(self, num_samples: int = 1000, image_size: int = 28, num_classes: int = 10):
        self.num_samples = num_samples
        self.image_size = image_size
        self.num_classes = num_classes
        self.input_size = image_size * image_size
        
        # توليد بيانات محاكاة
        self.X_train, self.y_train = self._generate_data(num_samples)
        self.X_test, self.y_test = self._generate_data(num_samples // 5)
        
        logger.info(f"تم توليد {num_samples} عينة تدريب و {num_samples // 5} عينة اختبار")
    
    def _generate_data(self, num_samples: int) -> Tuple[np.ndarray, np.ndarray]:
        """توليد بيانات محاكاة"""
        # توليد صور عشوائية مع أنماط بسيطة
        X = np.random.rand(num_samples, self.input_size) * 0.5
        
        # إضافة أنماط مميزة لكل فئة
        y = np.random.randint(0, self.num_classes, num_samples)
        
        for i in range(num_samples):
            class_id = y[i]
            # إضافة نمط مميز لكل فئة
            pattern_start = (class_id * self.input_size // self.num_classes)
            pattern_end = min(pattern_start + 50, self.input_size)
            X[i, pattern_start:pattern_end] += 0.5
        
        # تطبيع البيانات
        X = (X - X.mean()) / (X.std() + 1e-8)
        
        return X, y
    
    def get_batch(self, batch_size: int, train: bool = True) -> Tuple[Node, Node]:
        """الحصول على دفعة من البيانات"""
        if train:
            X, y = self.X_train, self.y_train
        else:
            X, y = self.X_test, self.y_test
        
        # اختيار عينات عشوائية
        indices = np.random.choice(len(X), batch_size, replace=False)
        batch_X = X[indices]
        batch_y = y[indices]
        
        # تحويل إلى one-hot encoding
        batch_y_onehot = np.zeros((batch_size, self.num_classes))
        batch_y_onehot[np.arange(batch_size), batch_y] = 1
        
        return tensor(batch_X, requires_grad=False), tensor(batch_y_onehot, requires_grad=False)

class MLPClassifier:
    """مصنف الشبكة العصبية متعددة الطبقات"""
    
    def __init__(self, input_size: int, hidden_sizes: List[int], num_classes: int, dropout_rate: float = 0.2):
        """
        تهيئة المصنف
        
        Args:
            input_size: حجم المدخل
            hidden_sizes: أحجام الطبقات المخفية
            num_classes: عدد الفئات
            dropout_rate: معدل Dropout
        """
        self.input_size = input_size
        self.hidden_sizes = hidden_sizes
        self.num_classes = num_classes
        
        # بناء النموذج
        layers = []
        
        # الطبقة الأولى
        layers.append(Linear(input_size, hidden_sizes[0]))
        layers.append(BatchNorm1d(hidden_sizes[0]))
        layers.append(ReLU())
        layers.append(Dropout(dropout_rate))
        
        # الطبقات المخفية
        for i in range(1, len(hidden_sizes)):
            layers.append(Linear(hidden_sizes[i-1], hidden_sizes[i]))
            layers.append(BatchNorm1d(hidden_sizes[i]))
            layers.append(ReLU())
            layers.append(Dropout(dropout_rate))
        
        # طبقة الخرج
        layers.append(Linear(hidden_sizes[-1], num_classes))
        layers.append(Sigmoid())  # للتصنيف متعدد الفئات
        
        self.model = Sequential(*layers)
        
        logger.info(f"تم إنشاء نموذج MLP: {input_size} -> {' -> '.join(map(str, hidden_sizes))} -> {num_classes}")
    
    def forward(self, x: Node) -> Node:
        """التمرير الأمامي"""
        return self.model(x)
    
    def get_parameters(self) -> List[Node]:
        """الحصول على معاملات النموذج"""
        return self.model.get_parameters()
    
    def train(self):
        """تعيين النموذج في وضع التدريب"""
        self.model.train()
    
    def eval(self):
        """تعيين النموذج في وضع التقييم"""
        self.model.eval()

def cross_entropy_loss(predictions: Node, targets: Node) -> Node:
    """دالة خسارة Cross Entropy"""
    # تطبيق log-softmax للاستقرار العددي
    log_probs = predictions.log()
    loss = -(targets * log_probs).sum(axis=1).mean()
    return loss

def accuracy(predictions: Node, targets: Node) -> float:
    """حساب دقة التصنيف"""
    pred_classes = np.argmax(predictions.data, axis=1)
    true_classes = np.argmax(targets.data, axis=1)
    return np.mean(pred_classes == true_classes)

def train_model(model: MLPClassifier, data_loader: MNISTSimulator, 
                optimizer, scheduler=None, num_epochs: int = 50, 
                batch_size: int = 32, eval_every: int = 5):
    """
    تدريب النموذج
    
    Args:
        model: النموذج
        data_loader: محمل البيانات
        optimizer: المحسن
        scheduler: جدولة معدل التعلم
        num_epochs: عدد العصور
        batch_size: حجم الدفعة
        eval_every: تقييم كل كم عصر
    """
    
    train_losses = []
    train_accuracies = []
    test_accuracies = []
    
    logger.info("بدء التدريب...")
    start_time = time.time()
    
    for epoch in range(num_epochs):
        model.train()
        epoch_losses = []
        epoch_accuracies = []
        
        # تدريب على عدة دفعات
        num_batches = max(1, data_loader.num_samples // batch_size)
        
        for batch_idx in range(num_batches):
            # الحصول على دفعة
            X_batch, y_batch = data_loader.get_batch(batch_size, train=True)
            
            # إعادة تعيين التدرجات
            optimizer.zero_grad()
            
            # التمرير الأمامي
            predictions = model.forward(X_batch)
            
            # حساب الخسارة
            loss = cross_entropy_loss(predictions, y_batch)
            
            # الانتشار الخلفي
            loss.backward()
            
            # تحديث المعاملات
            optimizer.step()
            
            # حفظ الإحصائيات
            epoch_losses.append(loss.item())
            epoch_accuracies.append(accuracy(predictions, y_batch))
        
        # حساب متوسط الخسارة والدقة للعصر
        avg_loss = np.mean(epoch_losses)
        avg_accuracy = np.mean(epoch_accuracies)
        
        train_losses.append(avg_loss)
        train_accuracies.append(avg_accuracy)
        
        # تحديث معدل التعلم
        if scheduler:
            scheduler.step(epoch)
        
        # التقييم
        if epoch % eval_every == 0 or epoch == num_epochs - 1:
            model.eval()
            
            # تقييم على بيانات الاختبار
            X_test, y_test = data_loader.get_batch(min(200, data_loader.num_samples // 5), train=False)
            test_predictions = model.forward(X_test)
            test_acc = accuracy(test_predictions, y_test)
            test_accuracies.append(test_acc)
            
            logger.info(f"العصر {epoch:3d}: خسارة={avg_loss:.4f}, دقة_تدريب={avg_accuracy:.4f}, دقة_اختبار={test_acc:.4f}, معدل_تعلم={optimizer.lr:.6f}")
        else:
            logger.info(f"العصر {epoch:3d}: خسارة={avg_loss:.4f}, دقة_تدريب={avg_accuracy:.4f}")
    
    training_time = time.time() - start_time
    logger.info(f"انتهى التدريب في {training_time:.2f} ثانية")
    
    return {
        'train_losses': train_losses,
        'train_accuracies': train_accuracies,
        'test_accuracies': test_accuracies,
        'training_time': training_time
    }

def plot_training_history(history: dict, save_path: str = None):
    """رسم تاريخ التدريب"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    
    # رسم الخسارة
    ax1.plot(history['train_losses'])
    ax1.set_title('Training Loss')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.grid(True)
    
    # رسم الدقة
    ax2.plot(history['train_accuracies'], label='Train Accuracy')
    if history['test_accuracies']:
        test_epochs = np.arange(0, len(history['train_accuracies']), 
                               len(history['train_accuracies']) // len(history['test_accuracies']))[:len(history['test_accuracies'])]
        ax2.plot(test_epochs, history['test_accuracies'], label='Test Accuracy')
    ax2.set_title('Accuracy')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Accuracy')
    ax2.legend()
    ax2.grid(True)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        logger.info(f"تم حفظ الرسم البياني في {save_path}")
    
    plt.show()

def main():
    """الدالة الرئيسية للتدريب"""
    
    # إعداد البيانات
    logger.info("إعداد البيانات...")
    data_loader = MNISTSimulator(num_samples=2000, image_size=28, num_classes=10)
    
    # إنشاء النموذج
    logger.info("إنشاء النموذج...")
    model = MLPClassifier(
        input_size=784,  # 28x28
        hidden_sizes=[128, 64, 32],
        num_classes=10,
        dropout_rate=0.2
    )
    
    # إعداد المحسن
    optimizer = Adam(model.get_parameters(), lr=0.001, weight_decay=1e-4)
    scheduler = StepLR(optimizer, step_size=20, gamma=0.5)
    
    # التدريب
    history = train_model(
        model=model,
        data_loader=data_loader,
        optimizer=optimizer,
        scheduler=scheduler,
        num_epochs=50,
        batch_size=32,
        eval_every=5
    )
    
    # رسم النتائج
    plot_training_history(history, '/home/ubuntu/unified_ai_system/training_history.png')
    
    # اختبار نهائي
    logger.info("إجراء اختبار نهائي...")
    model.eval()
    X_test, y_test = data_loader.get_batch(500, train=False)
    final_predictions = model.forward(X_test)
    final_accuracy = accuracy(final_predictions, y_test)
    
    logger.info(f"الدقة النهائية على بيانات الاختبار: {final_accuracy:.4f}")
    
    # عرض إحصائيات النموذج
    total_params = sum(param.data.size for param in model.get_parameters())
    logger.info(f"إجمالي عدد المعاملات: {total_params:,}")
    
    return model, history

if __name__ == "__main__":
    # تشغيل التدريب
    trained_model, training_history = main()
    
    logger.info("✅ تم إكمال مثال التدريب بنجاح!")
    logger.info("النظام جاهز للاستخدام في تطبيقات أكثر تعقيداً.")
