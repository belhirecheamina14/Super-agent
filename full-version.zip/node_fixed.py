"""
محرك التفاضل التلقائي المحسن - إصدار مصحح
Enhanced Automatic Differentiation Engine - Fixed Version

هذا المحرك يوفر حساب تدرجات صحيح ومحسن
"""

import numpy as np
from typing import List, Optional, Callable, Union, Tuple, Any
import logging

# إعداد نظام السجلات
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Node:
    """
    فئة Node المحسنة للحوسبة التفاضلية
    
    تدعم:
    - العمليات الرياضية الأساسية
    - الدوال التفعيل
    - الطبقات العصبية
    - التحسين والتدريب
    """
    
    def __init__(self, data: Union[float, np.ndarray], 
                 children: Optional[List['Node']] = None,
                 operation: Optional[str] = None,
                 requires_grad: bool = True):
        """
        تهيئة عقدة جديدة
        
        Args:
            data: البيانات (رقم أو مصفوفة)
            children: العقد الفرعية
            operation: نوع العملية
            requires_grad: هل تحتاج للتدرج
        """
        self.data = np.array(data, dtype=np.float32)
        self.grad = None
        self.children = children or []
        self.operation = operation
        self.requires_grad = requires_grad
        self._backward_fn = None
        self._id = id(self)
        
        # تهيئة التدرج
        if requires_grad:
            self.grad = np.zeros_like(self.data, dtype=np.float32)
    
    def __repr__(self) -> str:
        return f"Node(data={self.data}, grad={self.grad}, op={self.operation})"
    
    def __str__(self) -> str:
        return f"Node({self.data})"
    
    # العمليات الرياضية الأساسية
    def __add__(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """عملية الجمع"""
        other = self._ensure_node(other)
        result = Node(self.data + other.data, [self, other], 'add')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                # التعامل مع broadcasting في التدرجات
                grad_self = result.grad
                if self.data.shape != result.grad.shape:
                    # تقليل الأبعاد الإضافية
                    axes_to_sum = []
                    for i in range(len(result.grad.shape) - len(self.data.shape)):
                        axes_to_sum.append(i)
                    if axes_to_sum:
                        grad_self = np.sum(grad_self, axis=tuple(axes_to_sum))
                    
                    # تقليل الأبعاد التي تم broadcast عليها
                    for i, (dim_self, dim_result) in enumerate(zip(self.data.shape, grad_self.shape)):
                        if dim_self == 1 and dim_result > 1:
                            grad_self = np.sum(grad_self, axis=i, keepdims=True)
                
                self.grad += grad_self
            
            if other.requires_grad and other.grad is not None:
                # التعامل مع broadcasting في التدرجات
                grad_other = result.grad
                if other.data.shape != result.grad.shape:
                    # تقليل الأبعاد الإضافية
                    axes_to_sum = []
                    for i in range(len(result.grad.shape) - len(other.data.shape)):
                        axes_to_sum.append(i)
                    if axes_to_sum:
                        grad_other = np.sum(grad_other, axis=tuple(axes_to_sum))
                    
                    # تقليل الأبعاد التي تم broadcast عليها
                    for i, (dim_other, dim_result) in enumerate(zip(other.data.shape, grad_other.shape)):
                        if dim_other == 1 and dim_result > 1:
                            grad_other = np.sum(grad_other, axis=i, keepdims=True)
                
                other.grad += grad_other
        
        result._backward_fn = _backward
        return result
    
    def __radd__(self, other: Union[float, np.ndarray]) -> 'Node':
        return self.__add__(other)
    
    def __sub__(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """عملية الطرح"""
        other = self._ensure_node(other)
        result = Node(self.data - other.data, [self, other], 'sub')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += result.grad
            if other.requires_grad and other.grad is not None:
                other.grad -= result.grad
        
        result._backward_fn = _backward
        return result
    
    def __rsub__(self, other: Union[float, np.ndarray]) -> 'Node':
        other = self._ensure_node(other)
        return other.__sub__(self)
    
    def __mul__(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """عملية الضرب"""
        other = self._ensure_node(other)
        result = Node(self.data * other.data, [self, other], 'mul')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                # التعامل مع broadcasting في التدرجات
                grad_self = other.data * result.grad
                if self.data.shape != grad_self.shape:
                    # تقليل الأبعاد الإضافية
                    axes_to_sum = []
                    for i in range(len(grad_self.shape) - len(self.data.shape)):
                        axes_to_sum.append(i)
                    if axes_to_sum:
                        grad_self = np.sum(grad_self, axis=tuple(axes_to_sum))
                    
                    # تقليل الأبعاد التي تم broadcast عليها
                    for i, (dim_self, dim_grad) in enumerate(zip(self.data.shape, grad_self.shape)):
                        if dim_self == 1 and dim_grad > 1:
                            grad_self = np.sum(grad_self, axis=i, keepdims=True)
                
                self.grad += grad_self
            
            if other.requires_grad and other.grad is not None:
                # التعامل مع broadcasting في التدرجات
                grad_other = self.data * result.grad
                if other.data.shape != grad_other.shape:
                    # تقليل الأبعاد الإضافية
                    axes_to_sum = []
                    for i in range(len(grad_other.shape) - len(other.data.shape)):
                        axes_to_sum.append(i)
                    if axes_to_sum:
                        grad_other = np.sum(grad_other, axis=tuple(axes_to_sum))
                    
                    # تقليل الأبعاد التي تم broadcast عليها
                    for i, (dim_other, dim_grad) in enumerate(zip(other.data.shape, grad_other.shape)):
                        if dim_other == 1 and dim_grad > 1:
                            grad_other = np.sum(grad_other, axis=i, keepdims=True)
                
                other.grad += grad_other
        
        result._backward_fn = _backward
        return result
    
    def __rmul__(self, other: Union[float, np.ndarray]) -> 'Node':
        return self.__mul__(other)
    
    def __truediv__(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """عملية القسمة"""
        other = self._ensure_node(other)
        result = Node(self.data / other.data, [self, other], 'div')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += result.grad / other.data
            if other.requires_grad and other.grad is not None:
                other.grad -= result.grad * self.data / (other.data ** 2)
        
        result._backward_fn = _backward
        return result
    
    def __pow__(self, power: Union['Node', float]) -> 'Node':
        """عملية الأس"""
        if isinstance(power, (int, float)):
            result = Node(self.data ** power, [self], f'pow_{power}')
            
            def _backward():
                if self.requires_grad and self.grad is not None:
                    self.grad += power * (self.data ** (power - 1)) * result.grad
            
            result._backward_fn = _backward
            return result
        else:
            # للأسس المتغيرة
            power = self._ensure_node(power)
            result = Node(self.data ** power.data, [self, power], 'pow')
            
            def _backward():
                if self.requires_grad and self.grad is not None:
                    self.grad += power.data * (self.data ** (power.data - 1)) * result.grad
                if power.requires_grad and power.grad is not None:
                    power.grad += np.log(np.clip(self.data, 1e-8, None)) * result.data * result.grad
            
            result._backward_fn = _backward
            return result
    
    def __neg__(self) -> 'Node':
        """عملية النفي"""
        result = Node(-self.data, [self], 'neg')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad -= result.grad
        
        result._backward_fn = _backward
        return result
    
    # دوال التفعيل
    def relu(self) -> 'Node':
        """دالة ReLU"""
        result = Node(np.maximum(0, self.data), [self], 'relu')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += (self.data > 0).astype(np.float32) * result.grad
        
        result._backward_fn = _backward
        return result
    
    def sigmoid(self) -> 'Node':
        """دالة Sigmoid"""
        sigmoid_data = 1 / (1 + np.exp(-np.clip(self.data, -500, 500)))
        result = Node(sigmoid_data, [self], 'sigmoid')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += sigmoid_data * (1 - sigmoid_data) * result.grad
        
        result._backward_fn = _backward
        return result
    
    def tanh(self) -> 'Node':
        """دالة Tanh"""
        tanh_data = np.tanh(self.data)
        result = Node(tanh_data, [self], 'tanh')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += (1 - tanh_data ** 2) * result.grad
        
        result._backward_fn = _backward
        return result
    
    def softmax(self, axis: int = -1) -> 'Node':
        """دالة Softmax"""
        # تطبيق الاستقرار العددي
        shifted = self.data - np.max(self.data, axis=axis, keepdims=True)
        exp_data = np.exp(shifted)
        softmax_data = exp_data / np.sum(exp_data, axis=axis, keepdims=True)
        result = Node(softmax_data, [self], 'softmax')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                # تدرج Softmax معقد قليلاً
                s = softmax_data
                grad_input = s * result.grad
                grad_input -= s * np.sum(s * result.grad, axis=axis, keepdims=True)
                self.grad += grad_input
        
        result._backward_fn = _backward
        return result
    
    # عمليات المصفوفات
    def matmul(self, other: 'Node') -> 'Node':
        """ضرب المصفوفات"""
        other = self._ensure_node(other)
        result = Node(np.matmul(self.data, other.data), [self, other], 'matmul')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += np.matmul(result.grad, other.data.T)
            if other.requires_grad and other.grad is not None:
                other.grad += np.matmul(self.data.T, result.grad)
        
        result._backward_fn = _backward
        return result
    
    def sum(self, axis: Optional[Union[int, Tuple[int, ...]]] = None, 
            keepdims: bool = False) -> 'Node':
        """مجموع العناصر"""
        result = Node(np.sum(self.data, axis=axis, keepdims=keepdims), [self], 'sum')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                if axis is None:
                    self.grad += np.ones_like(self.data) * result.grad
                else:
                    grad_shape = list(self.data.shape)
                    if isinstance(axis, int):
                        axis_tuple = (axis,)
                    else:
                        axis_tuple = axis
                    
                    if not keepdims:
                        for ax in sorted(axis_tuple):
                            grad_shape[ax] = 1
                        expanded_grad = result.grad.reshape(grad_shape)
                    else:
                        expanded_grad = result.grad
                    
                    self.grad += np.broadcast_to(expanded_grad, self.data.shape)
        
        result._backward_fn = _backward
        return result
    
    def mean(self, axis: Optional[Union[int, Tuple[int, ...]]] = None, 
             keepdims: bool = False) -> 'Node':
        """متوسط العناصر"""
        if axis is None:
            n = self.data.size
        else:
            if isinstance(axis, int):
                n = self.data.shape[axis]
            else:
                n = np.prod([self.data.shape[ax] for ax in axis])
        
        return self.sum(axis=axis, keepdims=keepdims) / n
    
    def reshape(self, shape: Tuple[int, ...]) -> 'Node':
        """إعادة تشكيل المصفوفة"""
        result = Node(self.data.reshape(shape), [self], 'reshape')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += result.grad.reshape(self.data.shape)
        
        result._backward_fn = _backward
        return result
    
    def transpose(self, axes: Optional[Tuple[int, ...]] = None) -> 'Node':
        """نقل المصفوفة"""
        result = Node(np.transpose(self.data, axes), [self], 'transpose')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                if axes is None:
                    self.grad += result.grad.T
                else:
                    # إنشاء الترتيب العكسي
                    inv_axes = np.argsort(axes)
                    self.grad += np.transpose(result.grad, inv_axes)
        
        result._backward_fn = _backward
        return result
    
    # دوال الخسارة
    def mse_loss(self, target: 'Node') -> 'Node':
        """دالة خسارة متوسط مربع الخطأ"""
        target = self._ensure_node(target)
        diff = self - target
        return (diff * diff).mean()
    
    def exp(self) -> 'Node':
        """دالة الأس الطبيعي"""
        exp_data = np.exp(np.clip(self.data, -500, 500))
        result = Node(exp_data, [self], 'exp')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += exp_data * result.grad
        
        result._backward_fn = _backward
        return result
    
    def log(self) -> 'Node':
        """دالة اللوغاريتم الطبيعي"""
        log_data = np.log(np.clip(self.data, 1e-8, None))
        result = Node(log_data, [self], 'log')
        
        def _backward():
            if self.requires_grad and self.grad is not None:
                self.grad += result.grad / np.clip(self.data, 1e-8, None)
        
        result._backward_fn = _backward
        return result
    
    # الانتشار الخلفي
    def backward(self) -> None:
        """تنفيذ الانتشار الخلفي"""
        if not self.requires_grad:
            return
        
        # إعداد التدرج الأولي
        if self.grad is None:
            self.grad = np.ones_like(self.data, dtype=np.float32)
        else:
            # إذا لم يكن التدرج مهيأ، نهيئه بالواحدات
            if np.all(self.grad == 0):
                self.grad = np.ones_like(self.data, dtype=np.float32)
        
        # ترتيب طوبولوجي للعقد
        visited = set()
        topo_order = []
        
        def build_topo(node):
            if node._id not in visited:
                visited.add(node._id)
                for child in node.children:
                    build_topo(child)
                topo_order.append(node)
        
        build_topo(self)
        
        # تنفيذ الانتشار الخلفي
        for node in reversed(topo_order):
            if node._backward_fn:
                node._backward_fn()
    
    def zero_grad(self) -> None:
        """إعادة تعيين التدرجات إلى الصفر"""
        if self.requires_grad and self.grad is not None:
            self.grad.fill(0)
    
    def detach(self) -> 'Node':
        """فصل العقدة عن الرسم البياني للتدرج"""
        return Node(self.data.copy(), requires_grad=False)
    
    def item(self) -> float:
        """استخراج قيمة عددية واحدة"""
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)