"""
نظام التعلم المعزز الهرمي للنظام الموحد
Hierarchical Reinforcement Learning System for Unified System

يتضمن:
- HierarchicalState للتمثيل العلائقي
- HierarchicalQNetwork مع رؤوس متخصصة
- GoalDecompositionAgent للتخطيط
- MathPuzzleEnv للاختبار
"""

import sys
sys.path.append('/home/ubuntu/unified_ai_system')

import numpy as np
import random
from typing import List, Dict, Any, Tuple, Optional, Union
from dataclasses import dataclass
from abc import ABC, abstractmethod
import logging
import json
import time

from core.autodiff.node_fixed import Node, tensor, randn, zeros
from core.autodiff.layers import Sequential, Linear, ReLU, Sigmoid, Tanh
from core.autodiff.optimizers import Adam

# إعداد نظام السجلات
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class HierarchicalState:
    """حالة هرمية للتمثيل العلائقي"""
    low_level_state: np.ndarray  # الحالة منخفضة المستوى
    high_level_state: np.ndarray  # الحالة عالية المستوى
    goal_state: np.ndarray  # حالة الهدف
    context: Dict[str, Any]  # السياق الإضافي
    
    def to_vector(self) -> np.ndarray:
        """تحويل إلى متجه واحد"""
        return np.concatenate([
            self.low_level_state.flatten(),
            self.high_level_state.flatten(),
            self.goal_state.flatten()
        ])
    
    def get_state_size(self) -> int:
        """حساب حجم الحالة الكاملة"""
        return (self.low_level_state.size + 
                self.high_level_state.size + 
                self.goal_state.size)

class HierarchicalQNetwork:
    """شبكة Q هرمية مع رؤوس متخصصة"""
    
    def __init__(self, state_size: int, action_size: int, 
                 hidden_sizes: List[int] = [128, 64],
                 num_levels: int = 3):
        """
        تهيئة الشبكة الهرمية
        
        Args:
            state_size: حجم الحالة
            action_size: حجم الفعل
            hidden_sizes: أحجام الطبقات المخفية
            num_levels: عدد المستويات الهرمية
        """
        self.state_size = state_size
        self.action_size = action_size
        self.num_levels = num_levels
        
        # الشبكة المشتركة
        shared_layers = []
        prev_size = state_size
        
        for hidden_size in hidden_sizes:
            shared_layers.extend([
                Linear(prev_size, hidden_size),
                ReLU()
            ])
            prev_size = hidden_size
        
        self.shared_network = Sequential(*shared_layers)
        
        # رؤوس متخصصة لكل مستوى
        self.level_heads = []
        for level in range(num_levels):
            head = Sequential(
                Linear(prev_size, action_size),
                Tanh()  # قيم Q يمكن أن تكون سالبة
            )
            self.level_heads.append(head)
        
        logger.info(f"تم إنشاء HierarchicalQNetwork: {state_size} -> {hidden_sizes} -> {action_size} x {num_levels}")
    
    def forward(self, state: Node, level: int = 0) -> Node:
        """التمرير الأمامي للمستوى المحدد"""
        shared_features = self.shared_network(state)
        q_values = self.level_heads[level](shared_features)
        return q_values
    
    def get_parameters(self) -> List[Node]:
        """الحصول على جميع المعاملات"""
        params = self.shared_network.get_parameters()
        for head in self.level_heads:
            params.extend(head.get_parameters())
        return params
    
    def train(self):
        """تعيين في وضع التدريب"""
        self.shared_network.train()
        for head in self.level_heads:
            head.train()
    
    def eval(self):
        """تعيين في وضع التقييم"""
        self.shared_network.eval()
        for head in self.level_heads:
            head.eval()

class GoalDecompositionAgent:
    """وكيل تحليل الأهداف للتخطيط"""
    
    def __init__(self, goal_space_size: int, subgoal_space_size: int):
        """
        تهيئة وكيل تحليل الأهداف
        
        Args:
            goal_space_size: حجم مساحة الأهداف
            subgoal_space_size: حجم مساحة الأهداف الفرعية
        """
        self.goal_space_size = goal_space_size
        self.subgoal_space_size = subgoal_space_size
        
        # شبكة تحليل الأهداف
        self.decomposition_network = Sequential(
            Linear(goal_space_size, 64),
            ReLU(),
            Linear(64, 32),
            ReLU(),
            Linear(32, subgoal_space_size * 3),  # 3 أهداف فرعية كحد أقصى
            Sigmoid()
        )
        
        self.optimizer = Adam(self.decomposition_network.get_parameters(), lr=0.001)
        
        logger.info(f"تم إنشاء GoalDecompositionAgent: {goal_space_size} -> {subgoal_space_size}")
    
    def decompose_goal(self, goal: np.ndarray) -> List[np.ndarray]:
        """تحليل الهدف إلى أهداف فرعية"""
        goal_tensor = tensor(goal.reshape(1, -1), requires_grad=False)
        
        self.decomposition_network.eval()
        output = self.decomposition_network(goal_tensor)
        
        # تحويل الخرج إلى أهداف فرعية
        output_data = output.data.reshape(-1)
        subgoals = []
        
        for i in range(3):  # 3 أهداف فرعية كحد أقصى
            start_idx = i * self.subgoal_space_size
            end_idx = start_idx + self.subgoal_space_size
            subgoal = output_data[start_idx:end_idx]
            
            # تحقق من أن الهدف الفرعي ليس فارغاً
            if np.sum(subgoal) > 0.1:
                subgoals.append(subgoal)
        
        return subgoals if subgoals else [goal[:self.subgoal_space_size]]
    
    def train_decomposition(self, goal: np.ndarray, achieved_subgoals: List[np.ndarray], 
                           success: bool) -> float:
        """تدريب شبكة تحليل الأهداف"""
        goal_tensor = tensor(goal.reshape(1, -1), requires_grad=True)
        
        self.decomposition_network.train()
        predicted_subgoals = self.decomposition_network(goal_tensor)
        
        # إنشاء الهدف المطلوب
        target = np.zeros(self.subgoal_space_size * 3)
        for i, subgoal in enumerate(achieved_subgoals[:3]):
            start_idx = i * self.subgoal_space_size
            end_idx = start_idx + len(subgoal)
            target[start_idx:end_idx] = subgoal[:self.subgoal_space_size]
        
        target_tensor = tensor(target.reshape(1, -1), requires_grad=False)
        
        # حساب الخسارة
        loss = ((predicted_subgoals - target_tensor) ** 2).mean()
        
        # إضافة مكافأة النجاح
        if success:
            loss = loss * 0.5  # تقليل الخسارة عند النجاح
        
        # التدريب
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        return loss.item()

class HierarchicalAgent:
    """الوكيل الهرمي الرئيسي"""
    
    def __init__(self, state_size: int, action_size: int, goal_size: int,
                 learning_rate: float = 0.001, epsilon: float = 0.1,
                 gamma: float = 0.99, num_levels: int = 3):
        """
        تهيئة الوكيل الهرمي
        
        Args:
            state_size: حجم الحالة
            action_size: حجم الفعل
            goal_size: حجم الهدف
            learning_rate: معدل التعلم
            epsilon: معامل الاستكشاف
            gamma: معامل الخصم
            num_levels: عدد المستويات الهرمية
        """
        self.state_size = state_size
        self.action_size = action_size
        self.goal_size = goal_size
        self.epsilon = epsilon
        self.gamma = gamma
        self.num_levels = num_levels
        
        # الشبكات الرئيسية والهدف
        self.q_network = HierarchicalQNetwork(state_size, action_size, num_levels=num_levels)
        self.target_network = HierarchicalQNetwork(state_size, action_size, num_levels=num_levels)
        
        # وكيل تحليل الأهداف
        self.goal_agent = GoalDecompositionAgent(goal_size, goal_size // 2)
        
        # المحسن
        self.optimizer = Adam(self.q_network.get_parameters(), lr=learning_rate)
        
        # ذاكرة الخبرة
        self.memory = []
        self.memory_size = 10000
        
        # إحصائيات
        self.episode_rewards = []
        self.episode_lengths = []
        self.training_losses = []
        
        logger.info(f"تم إنشاء HierarchicalAgent: state={state_size}, action={action_size}, levels={num_levels}")
    
    def select_action(self, state: HierarchicalState, level: int = 0) -> int:
        """اختيار فعل باستخدام epsilon-greedy"""
        if random.random() < self.epsilon:
            return random.randint(0, self.action_size - 1)
        
        state_vector = tensor(state.to_vector().reshape(1, -1), requires_grad=False)
        
        self.q_network.eval()
        q_values = self.q_network.forward(state_vector, level)
        
        return int(np.argmax(q_values.data))
    
    def store_experience(self, state: HierarchicalState, action: int, reward: float,
                        next_state: HierarchicalState, done: bool, level: int = 0):
        """حفظ الخبرة في الذاكرة"""
        experience = {
            'state': state.to_vector(),
            'action': action,
            'reward': reward,
            'next_state': next_state.to_vector(),
            'done': done,
            'level': level
        }
        
        self.memory.append(experience)
        
        # الحفاظ على حجم الذاكرة
        if len(self.memory) > self.memory_size:
            self.memory.pop(0)
    
    def train_step(self, batch_size: int = 32) -> float:
        """خطوة تدريب واحدة"""
        if len(self.memory) < batch_size:
            return 0.0
        
        # أخذ عينة عشوائية من الذاكرة
        batch = random.sample(self.memory, batch_size)
        
        states = np.array([exp['state'] for exp in batch])
        actions = np.array([exp['action'] for exp in batch])
        rewards = np.array([exp['reward'] for exp in batch])
        next_states = np.array([exp['next_state'] for exp in batch])
        dones = np.array([exp['done'] for exp in batch])
        levels = np.array([exp['level'] for exp in batch])
        
        # تحويل إلى tensors
        states_tensor = tensor(states, requires_grad=False)
        next_states_tensor = tensor(next_states, requires_grad=False)
        rewards_tensor = tensor(rewards.reshape(-1, 1), requires_grad=False)
        
        total_loss = 0.0
        
        # تدريب كل مستوى
        for level in range(self.num_levels):
            level_mask = (levels == level)
            if not np.any(level_mask):
                continue
            
            level_indices = np.where(level_mask)[0]
            
            # Q-values الحالية
            self.q_network.train()
            current_q_values = self.q_network.forward(states_tensor, level)
            
            # اختيار Q-values للأفعال المحددة
            level_actions = actions[level_mask]
            q_values_data = current_q_values.data
            current_q_values_selected = []
            for i, action in enumerate(level_actions):
                current_q_values_selected.append(q_values_data[level_indices[i], action])
            current_q_values_selected = tensor(np.array(current_q_values_selected), requires_grad=True)
            
            # Q-values الهدف
            self.target_network.eval()
            next_q_values = self.target_network.forward(next_states_tensor, level)
            max_next_q_values = next_q_values.data.max(axis=1)
            
            # حساب الهدف
            targets = rewards[level_mask] + self.gamma * max_next_q_values[level_mask] * (1 - dones[level_mask])
            targets_tensor = tensor(targets, requires_grad=False)
            
            # حساب الخسارة
            loss = ((current_q_values_selected - targets_tensor) ** 2).mean()
            total_loss += loss.item()
            
            # التدريب
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
        
        return total_loss / self.num_levels
    
    def update_target_network(self):
        """تحديث الشبكة الهدف"""
        # نسخ الأوزان من الشبكة الرئيسية إلى الشبكة الهدف
        main_params = self.q_network.get_parameters()
        target_params = self.target_network.get_parameters()
        
        for main_param, target_param in zip(main_params, target_params):
            target_param.data = main_param.data.copy()
    
    def decay_epsilon(self, decay_rate: float = 0.995):
        """تقليل معامل الاستكشاف"""
        self.epsilon = max(0.01, self.epsilon * decay_rate)

class MathPuzzleEnv:
    """بيئة الألغاز الرياضية للاختبار"""
    
    def __init__(self, max_number: int = 10, target_range: Tuple[int, int] = (10, 50)):
        """
        تهيئة بيئة الألغاز الرياضية
        
        Args:
            max_number: أقصى رقم في اللغز
            target_range: نطاق الهدف المطلوب
        """
        self.max_number = max_number
        self.target_range = target_range
        self.reset()
        
        # تعريف الأفعال: [+1, -1, *2, /2, reset]
        self.action_space_size = 5
        self.state_space_size = 4  # [current_value, target, steps, max_steps]
        
        logger.info(f"تم إنشاء MathPuzzleEnv: max_number={max_number}, target_range={target_range}")
    
    def reset(self) -> HierarchicalState:
        """إعادة تعيين البيئة"""
        self.current_value = random.randint(1, self.max_number)
        self.target = random.randint(*self.target_range)
        self.steps = 0
        self.max_steps = 20
        
        return self._get_state()
    
    def _get_state(self) -> HierarchicalState:
        """الحصول على الحالة الحالية"""
        low_level = np.array([self.current_value, self.steps], dtype=np.float32)
        high_level = np.array([self.target, self.max_steps - self.steps], dtype=np.float32)
        goal = np.array([self.target - self.current_value], dtype=np.float32)
        
        context = {
            'current_value': self.current_value,
            'target': self.target,
            'steps': self.steps,
            'max_steps': self.max_steps
        }
        
        return HierarchicalState(low_level, high_level, goal, context)
    
    def step(self, action: int) -> Tuple[HierarchicalState, float, bool, Dict[str, Any]]:
        """تنفيذ خطوة في البيئة"""
        old_value = self.current_value
        
        # تنفيذ الفعل
        if action == 0:  # +1
            self.current_value += 1
        elif action == 1:  # -1
            self.current_value = max(1, self.current_value - 1)
        elif action == 2:  # *2
            self.current_value *= 2
        elif action == 3:  # /2
            self.current_value = max(1, self.current_value // 2)
        elif action == 4:  # reset
            self.current_value = random.randint(1, self.max_number)
        
        self.steps += 1
        
        # حساب المكافأة
        reward = self._calculate_reward(old_value)
        
        # التحقق من انتهاء الحلقة
        done = (self.current_value == self.target) or (self.steps >= self.max_steps)
        
        info = {
            'success': self.current_value == self.target,
            'steps': self.steps,
            'distance': abs(self.current_value - self.target)
        }
        
        return self._get_state(), reward, done, info
    
    def _calculate_reward(self, old_value: int) -> float:
        """حساب المكافأة"""
        old_distance = abs(old_value - self.target)
        new_distance = abs(self.current_value - self.target)
        
        # مكافأة الوصول للهدف
        if self.current_value == self.target:
            return 100.0
        
        # مكافأة الاقتراب من الهدف
        if new_distance < old_distance:
            return 10.0 / (new_distance + 1)
        elif new_distance > old_distance:
            return -5.0 / (new_distance + 1)
        else:
            return -0.1  # عقاب صغير للوقت

def train_hierarchical_agent(episodes: int = 500, render_every: int = 100) -> HierarchicalAgent:
    """تدريب الوكيل الهرمي"""
    
    # إنشاء البيئة والوكيل
    env = MathPuzzleEnv()
    
    # حساب حجم الحالة الصحيح
    sample_state = env.reset()
    actual_state_size = sample_state.get_state_size()
    
    agent = HierarchicalAgent(
        state_size=actual_state_size,  # الحجم الفعلي للحالة
        action_size=env.action_space_size,
        goal_size=1,
        learning_rate=0.001,
        epsilon=0.9
    )
    
    logger.info(f"بدء تدريب الوكيل الهرمي لـ {episodes} حلقة...")
    
    for episode in range(episodes):
        state = env.reset()
        total_reward = 0.0
        steps = 0
        
        while True:
            # اختيار المستوى بناءً على المسافة من الهدف
            distance = abs(state.context['current_value'] - state.context['target'])
            if distance > 20:
                level = 2  # مستوى عالي للمسافات الكبيرة
            elif distance > 5:
                level = 1  # مستوى متوسط
            else:
                level = 0  # مستوى منخفض للضبط الدقيق
            
            # اختيار وتنفيذ الفعل
            action = agent.select_action(state, level)
            next_state, reward, done, info = env.step(action)
            
            # حفظ الخبرة
            agent.store_experience(state, action, reward, next_state, done, level)
            
            # التدريب
            if len(agent.memory) > 32:
                loss = agent.train_step()
                agent.training_losses.append(loss)
            
            total_reward += reward
            steps += 1
            state = next_state
            
            if done:
                break
        
        # حفظ إحصائيات الحلقة
        agent.episode_rewards.append(total_reward)
        agent.episode_lengths.append(steps)
        
        # تحديث الشبكة الهدف
        if episode % 10 == 0:
            agent.update_target_network()
        
        # تقليل الاستكشاف
        agent.decay_epsilon()
        
        # طباعة التقدم
        if episode % render_every == 0:
            avg_reward = np.mean(agent.episode_rewards[-render_every:])
            avg_length = np.mean(agent.episode_lengths[-render_every:])
            success_rate = np.mean([1 if r > 50 else 0 for r in agent.episode_rewards[-render_every:]])
            
            logger.info(f"الحلقة {episode}: متوسط المكافأة = {avg_reward:.2f}, "
                       f"متوسط الطول = {avg_length:.1f}, معدل النجاح = {success_rate:.2f}, "
                       f"epsilon = {agent.epsilon:.3f}")
    
    logger.info("انتهى التدريب!")
    return agent

# اختبار سريع
if __name__ == "__main__":
    # تدريب الوكيل
    trained_agent = train_hierarchical_agent(episodes=200, render_every=50)
    
    # اختبار الوكيل المدرب
    logger.info("\nاختبار الوكيل المدرب...")
    env = MathPuzzleEnv()
    
    test_episodes = 10
    successes = 0
    
    for episode in range(test_episodes):
        state = env.reset()
        total_reward = 0.0
        steps = 0
        
        logger.info(f"اختبار {episode + 1}: القيمة الأولية = {state.context['current_value']}, "
                   f"الهدف = {state.context['target']}")
        
        while True:
            # اختيار المستوى
            distance = abs(state.context['current_value'] - state.context['target'])
            if distance > 20:
                level = 2
            elif distance > 5:
                level = 1
            else:
                level = 0
            
            # اختيار الفعل (بدون استكشاف)
            old_epsilon = trained_agent.epsilon
            trained_agent.epsilon = 0.0
            action = trained_agent.select_action(state, level)
            trained_agent.epsilon = old_epsilon
            
            next_state, reward, done, info = env.step(action)
            total_reward += reward
            steps += 1
            state = next_state
            
            if done:
                if info['success']:
                    successes += 1
                    logger.info(f"  نجح في {steps} خطوات! المكافأة = {total_reward:.1f}")
                else:
                    logger.info(f"  فشل بعد {steps} خطوات. المسافة النهائية = {info['distance']}")
                break
    
    success_rate = successes / test_episodes
    logger.info(f"\nمعدل النجاح النهائي: {success_rate:.2f} ({successes}/{test_episodes})")
    
    # حفظ النتائج
    results = {
        'episode_rewards': trained_agent.episode_rewards,
        'episode_lengths': trained_agent.episode_lengths,
        'training_losses': trained_agent.training_losses,
        'final_success_rate': success_rate,
        'test_successes': successes,
        'test_episodes': test_episodes
    }
    
    with open('/home/ubuntu/unified_ai_system/hrl_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    logger.info("✅ اختبار نظام التعلم المعزز الهرمي مكتمل بنجاح!")
