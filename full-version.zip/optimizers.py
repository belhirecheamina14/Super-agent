"""
محسنات التدريب للنظام الموحد
Training Optimizers for Unified System

تتضمن:
- SGD (Stochastic Gradient Descent)
- Adam
- RMSprop
- AdaGrad
"""

import numpy as np
from typing import List, Optional, Dict, Any
from .node_fixed import Node
import logging

logger = logging.getLogger(__name__)

class Optimizer:
    """الفئة الأساسية لجميع المحسنات"""
    
    def __init__(self, parameters: List[Node], lr: float = 0.01):
        """
        تهيئة المحسن
        
        Args:
            parameters: قائمة المعاملات القابلة للتدريب
            lr: معدل التعلم
        """
        self.parameters = parameters
        self.lr = lr
        self.step_count = 0
    
    def zero_grad(self):
        """إعادة تعيين جميع التدرجات إلى الصفر"""
        for param in self.parameters:
            if param.requires_grad and param.grad is not None:
                param.grad.fill(0)
    
    def step(self):
        """تنفيذ خطوة تحسين واحدة"""
        raise NotImplementedError
    
    def state_dict(self) -> Dict[str, Any]:
        """حفظ حالة المحسن"""
        return {
            'lr': self.lr,
            'step_count': self.step_count
        }
    
    def load_state_dict(self, state_dict: Dict[str, Any]):
        """تحميل حالة المحسن"""
        self.lr = state_dict.get('lr', self.lr)
        self.step_count = state_dict.get('step_count', 0)

class SGD(Optimizer):
    """محسن Stochastic Gradient Descent"""
    
    def __init__(self, parameters: List[Node], lr: float = 0.01, 
                 momentum: float = 0.0, weight_decay: float = 0.0):
        """
        تهيئة محسن SGD
        
        Args:
            parameters: قائمة المعاملات
            lr: معدل التعلم
            momentum: معامل الزخم
            weight_decay: معامل تحلل الأوزان (L2 regularization)
        """
        super().__init__(parameters, lr)
        self.momentum = momentum
        self.weight_decay = weight_decay
        
        # تهيئة متجهات الزخم
        self.velocity = []
        for param in self.parameters:
            if param.requires_grad:
                self.velocity.append(np.zeros_like(param.data))
            else:
                self.velocity.append(None)
    
    def step(self):
        """تنفيذ خطوة SGD"""
        for i, param in enumerate(self.parameters):
            if param.requires_grad and param.grad is not None:
                grad = param.grad.copy()
                
                # إضافة weight decay
                if self.weight_decay > 0:
                    grad += self.weight_decay * param.data
                
                # تطبيق الزخم
                if self.momentum > 0:
                    if self.velocity[i] is None:
                        self.velocity[i] = np.zeros_like(param.data)
                    
                    self.velocity[i] = self.momentum * self.velocity[i] + grad
                    grad = self.velocity[i]
                
                # تحديث المعاملات
                param.data -= self.lr * grad
        
        self.step_count += 1
    
    def state_dict(self) -> Dict[str, Any]:
        """حفظ حالة SGD"""
        state = super().state_dict()
        state.update({
            'momentum': self.momentum,
            'weight_decay': self.weight_decay,
            'velocity': [v.copy() if v is not None else None for v in self.velocity]
        })
        return state
    
    def load_state_dict(self, state_dict: Dict[str, Any]):
        """تحميل حالة SGD"""
        super().load_state_dict(state_dict)
        self.momentum = state_dict.get('momentum', self.momentum)
        self.weight_decay = state_dict.get('weight_decay', self.weight_decay)
        if 'velocity' in state_dict:
            self.velocity = state_dict['velocity']

class Adam(Optimizer):
    """محسن Adam (Adaptive Moment Estimation)"""
    
    def __init__(self, parameters: List[Node], lr: float = 0.001,
                 beta1: float = 0.9, beta2: float = 0.999, 
                 eps: float = 1e-8, weight_decay: float = 0.0):
        """
        تهيئة محسن Adam
        
        Args:
            parameters: قائمة المعاملات
            lr: معدل التعلم
            beta1: معامل تحلل المتوسط الأول
            beta2: معامل تحلل المتوسط الثاني
            eps: قيمة صغيرة لتجنب القسمة على صفر
            weight_decay: معامل تحلل الأوزان
        """
        super().__init__(parameters, lr)
        self.beta1 = beta1
        self.beta2 = beta2
        self.eps = eps
        self.weight_decay = weight_decay
        
        # تهيئة متجهات العزوم
        self.m = []  # المتوسط الأول (الزخم)
        self.v = []  # المتوسط الثاني (التباين)
        
        for param in self.parameters:
            if param.requires_grad:
                self.m.append(np.zeros_like(param.data))
                self.v.append(np.zeros_like(param.data))
            else:
                self.m.append(None)
                self.v.append(None)
    
    def step(self):
        """تنفيذ خطوة Adam"""
        self.step_count += 1
        
        for i, param in enumerate(self.parameters):
            if param.requires_grad and param.grad is not None:
                grad = param.grad.copy()
                
                # إضافة weight decay
                if self.weight_decay > 0:
                    grad += self.weight_decay * param.data
                
                # تحديث العزوم
                self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
                self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (grad ** 2)
                
                # تصحيح التحيز
                m_hat = self.m[i] / (1 - self.beta1 ** self.step_count)
                v_hat = self.v[i] / (1 - self.beta2 ** self.step_count)
                
                # تحديث المعاملات
                param.data -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)
    
    def state_dict(self) -> Dict[str, Any]:
        """حفظ حالة Adam"""
        state = super().state_dict()
        state.update({
            'beta1': self.beta1,
            'beta2': self.beta2,
            'eps': self.eps,
            'weight_decay': self.weight_decay,
            'm': [m.copy() if m is not None else None for m in self.m],
            'v': [v.copy() if v is not None else None for v in self.v]
        })
        return state
    
    def load_state_dict(self, state_dict: Dict[str, Any]):
        """تحميل حالة Adam"""
        super().load_state_dict(state_dict)
        self.beta1 = state_dict.get('beta1', self.beta1)
        self.beta2 = state_dict.get('beta2', self.beta2)
        self.eps = state_dict.get('eps', self.eps)
        self.weight_decay = state_dict.get('weight_decay', self.weight_decay)
        if 'm' in state_dict:
            self.m = state_dict['m']
        if 'v' in state_dict:
            self.v = state_dict['v']

class RMSprop(Optimizer):
    """محسن RMSprop"""
    
    def __init__(self, parameters: List[Node], lr: float = 0.01,
                 alpha: float = 0.99, eps: float = 1e-8, 
                 weight_decay: float = 0.0, momentum: float = 0.0):
        """
        تهيئة محسن RMSprop
        
        Args:
            parameters: قائمة المعاملات
            lr: معدل التعلم
            alpha: معامل التنعيم
            eps: قيمة صغيرة لتجنب القسمة على صفر
            weight_decay: معامل تحلل الأوزان
            momentum: معامل الزخم
        """
        super().__init__(parameters, lr)
        self.alpha = alpha
        self.eps = eps
        self.weight_decay = weight_decay
        self.momentum = momentum
        
        # تهيئة متجهات التباين والزخم
        self.v = []  # متوسط مربع التدرجات
        self.buf = []  # متجه الزخم
        
        for param in self.parameters:
            if param.requires_grad:
                self.v.append(np.zeros_like(param.data))
                self.buf.append(np.zeros_like(param.data))
            else:
                self.v.append(None)
                self.buf.append(None)
    
    def step(self):
        """تنفيذ خطوة RMSprop"""
        for i, param in enumerate(self.parameters):
            if param.requires_grad and param.grad is not None:
                grad = param.grad.copy()
                
                # إضافة weight decay
                if self.weight_decay > 0:
                    grad += self.weight_decay * param.data
                
                # تحديث متوسط مربع التدرجات
                self.v[i] = self.alpha * self.v[i] + (1 - self.alpha) * (grad ** 2)
                
                # حساب التحديث
                update = grad / (np.sqrt(self.v[i]) + self.eps)
                
                # تطبيق الزخم
                if self.momentum > 0:
                    self.buf[i] = self.momentum * self.buf[i] + update
                    update = self.buf[i]
                
                # تحديث المعاملات
                param.data -= self.lr * update
        
        self.step_count += 1
    
    def state_dict(self) -> Dict[str, Any]:
        """حفظ حالة RMSprop"""
        state = super().state_dict()
        state.update({
            'alpha': self.alpha,
            'eps': self.eps,
            'weight_decay': self.weight_decay,
            'momentum': self.momentum,
            'v': [v.copy() if v is not None else None for v in self.v],
            'buf': [buf.copy() if buf is not None else None for buf in self.buf]
        })
        return state
    
    def load_state_dict(self, state_dict: Dict[str, Any]):
        """تحميل حالة RMSprop"""
        super().load_state_dict(state_dict)
        self.alpha = state_dict.get('alpha', self.alpha)
        self.eps = state_dict.get('eps', self.eps)
        self.weight_decay = state_dict.get('weight_decay', self.weight_decay)
        self.momentum = state_dict.get('momentum', self.momentum)
        if 'v' in state_dict:
            self.v = state_dict['v']
        if 'buf' in state_dict:
            self.buf = state_dict['buf']

class AdaGrad(Optimizer):
    """محسن AdaGrad"""
    
    def __init__(self, parameters: List[Node], lr: float = 0.01,
                 eps: float = 1e-10, weight_decay: float = 0.0):
        """
        تهيئة محسن AdaGrad
        
        Args:
            parameters: قائمة المعاملات
            lr: معدل التعلم
            eps: قيمة صغيرة لتجنب القسمة على صفر
            weight_decay: معامل تحلل الأوزان
        """
        super().__init__(parameters, lr)
        self.eps = eps
        self.weight_decay = weight_decay
        
        # تهيئة متجهات مجموع مربع التدرجات
        self.sum_sq_grad = []
        
        for param in self.parameters:
            if param.requires_grad:
                self.sum_sq_grad.append(np.zeros_like(param.data))
            else:
                self.sum_sq_grad.append(None)
    
    def step(self):
        """تنفيذ خطوة AdaGrad"""
        for i, param in enumerate(self.parameters):
            if param.requires_grad and param.grad is not None:
                grad = param.grad.copy()
                
                # إضافة weight decay
                if self.weight_decay > 0:
                    grad += self.weight_decay * param.data
                
                # تحديث مجموع مربع التدرجات
                self.sum_sq_grad[i] += grad ** 2
                
                # تحديث المعاملات
                param.data -= self.lr * grad / (np.sqrt(self.sum_sq_grad[i]) + self.eps)
        
        self.step_count += 1
    
    def state_dict(self) -> Dict[str, Any]:
        """حفظ حالة AdaGrad"""
        state = super().state_dict()
        state.update({
            'eps': self.eps,
            'weight_decay': self.weight_decay,
            'sum_sq_grad': [s.copy() if s is not None else None for s in self.sum_sq_grad]
        })
        return state
    
    def load_state_dict(self, state_dict: Dict[str, Any]):
        """تحميل حالة AdaGrad"""
        super().load_state_dict(state_dict)
        self.eps = state_dict.get('eps', self.eps)
        self.weight_decay = state_dict.get('weight_decay', self.weight_decay)
        if 'sum_sq_grad' in state_dict:
            self.sum_sq_grad = state_dict['sum_sq_grad']

class LRScheduler:
    """جدولة معدل التعلم"""
    
    def __init__(self, optimizer: Optimizer):
        self.optimizer = optimizer
        self.base_lr = optimizer.lr
    
    def step(self, epoch: Optional[int] = None):
        """تحديث معدل التعلم"""
        raise NotImplementedError

class StepLR(LRScheduler):
    """تقليل معدل التعلم كل step_size epochs"""
    
    def __init__(self, optimizer: Optimizer, step_size: int, gamma: float = 0.1):
        super().__init__(optimizer)
        self.step_size = step_size
        self.gamma = gamma
        self.last_epoch = 0
    
    def step(self, epoch: Optional[int] = None):
        if epoch is None:
            epoch = self.last_epoch + 1
        self.last_epoch = epoch
        
        # حساب معدل التعلم الجديد
        new_lr = self.base_lr * (self.gamma ** (epoch // self.step_size))
        self.optimizer.lr = new_lr

class ExponentialLR(LRScheduler):
    """تقليل معدل التعلم بشكل أسي"""
    
    def __init__(self, optimizer: Optimizer, gamma: float):
        super().__init__(optimizer)
        self.gamma = gamma
        self.last_epoch = 0
    
    def step(self, epoch: Optional[int] = None):
        if epoch is None:
            epoch = self.last_epoch + 1
        self.last_epoch = epoch
        
        # حساب معدل التعلم الجديد
        new_lr = self.base_lr * (self.gamma ** epoch)
        self.optimizer.lr = new_lr

class CosineAnnealingLR(LRScheduler):
    """جدولة معدل التعلم باستخدام دالة الجيب التمام"""
    
    def __init__(self, optimizer: Optimizer, T_max: int, eta_min: float = 0):
        super().__init__(optimizer)
        self.T_max = T_max
        self.eta_min = eta_min
        self.last_epoch = 0
    
    def step(self, epoch: Optional[int] = None):
        if epoch is None:
            epoch = self.last_epoch + 1
        self.last_epoch = epoch
        
        # حساب معدل التعلم الجديد
        new_lr = self.eta_min + (self.base_lr - self.eta_min) * \
                 (1 + np.cos(np.pi * epoch / self.T_max)) / 2
        self.optimizer.lr = new_lr

# اختبار سريع
if __name__ == "__main__":
    from .layers import Linear
    from .node_fixed import randn, tensor
    
    print('=== اختبار المحسنات ===')
    
    # إنشاء نموذج بسيط
    model = Linear(2, 1)
    
    # بيانات تدريب بسيطة
    X = tensor([[1.0, 2.0], [2.0, 3.0], [3.0, 4.0]], requires_grad=False)
    y = tensor([[3.0], [5.0], [7.0]], requires_grad=False)  # y = x1 + x2
    
    # اختبار محسنات مختلفة
    optimizers = {
        'SGD': SGD(model.get_parameters(), lr=0.01),
        'Adam': Adam(model.get_parameters(), lr=0.01),
        'RMSprop': RMSprop(model.get_parameters(), lr=0.01),
        'AdaGrad': AdaGrad(model.get_parameters(), lr=0.01)
    }
    
    for name, optimizer in optimizers.items():
        print(f'\n{name}:')
        
        # إعادة تهيئة النموذج
        model.weight.data = np.random.randn(*model.weight.shape) * 0.1
        model.bias.data = np.random.randn(*model.bias.shape) * 0.1
        
        # تدريب لعدة خطوات
        for step in range(10):
            optimizer.zero_grad()
            
            pred = model(X)
            loss = ((pred - y) ** 2).mean()
            
            loss.backward()
            optimizer.step()
            
            if step % 5 == 0:
                print(f'  Step {step}: Loss = {loss.data:.4f}')
    
    logger.info("اختبار المحسنات مكتمل بنجاح!")
