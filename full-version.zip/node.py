"""
محرك التفاضل التلقائي - فئة Node الأساسية
Automatic Differentiation Engine - Core Node Class

هذا المحرك يوفر الأساس للحوسبة التفاضلية في النظام الموحد
"""

import numpy as np
from typing import List, Optional, Callable, Union, Tuple, Any
import weakref
from functools import wraps
import logging

# إعداد نظام السجلات
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Node:
    """
    فئة Node الأساسية للحوسبة التفاضلية
    
    تدعم:
    - العمليات الرياضية الأساسية
    - الدوال التفعيل
    - الطبقات العصبية
    - التحسين والتدريب
    """
    
    def __init__(self, data: Union[float, np.ndarray], 
                 children: Optional[List['Node']] = None,
                 operation: Optional[str] = None,
                 requires_grad: bool = True):
        """
        تهيئة عقدة جديدة
        
        Args:
            data: البيانات (رقم أو مصفوفة)
            children: العقد الفرعية
            operation: نوع العملية
            requires_grad: هل تحتاج للتدرج
        """
        self.data = np.array(data, dtype=np.float32)
        self.grad = np.zeros_like(self.data) if requires_grad else None
        self.children = children or []
        self.operation = operation
        self.requires_grad = requires_grad
        self._backward_fn = None
        self._id = id(self)
    
    def __repr__(self) -> str:
        return f"Node(data={self.data}, grad={self.grad}, op={self.operation})"
    
    def __str__(self) -> str:
        return f"Node({self.data})"
    
    # العمليات الرياضية الأساسية
    def __add__(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """عملية الجمع"""
        other = self._ensure_node(other)
        result = Node(self.data + other.data, [self, other], 'add')
        
        def _backward():
            if self.requires_grad:
                self.grad += result.grad
            if other.requires_grad:
                other.grad += result.grad
        
        result._backward_fn = _backward
        return result
    
    def __radd__(self, other: Union[float, np.ndarray]) -> 'Node':
        return self.__add__(other)
    
    def __sub__(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """عملية الطرح"""
        other = self._ensure_node(other)
        result = Node(self.data - other.data, [self, other], 'sub')
        
        def _backward():
            if self.requires_grad:
                self.grad += result.grad
            if other.requires_grad:
                other.grad -= result.grad
        
        result._backward_fn = _backward
        return result
    
    def __rsub__(self, other: Union[float, np.ndarray]) -> 'Node':
        other = self._ensure_node(other)
        return other.__sub__(self)
    
    def __mul__(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """عملية الضرب"""
        other = self._ensure_node(other)
        result = Node(self.data * other.data, [self, other], 'mul')
        
        def _backward():
            if self.requires_grad:
                self.grad += other.data * result.grad
            if other.requires_grad:
                other.grad += self.data * result.grad
        
        result._backward_fn = _backward
        return result
    
    def __rmul__(self, other: Union[float, np.ndarray]) -> 'Node':
        return self.__mul__(other)
    
    def __truediv__(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """عملية القسمة"""
        other = self._ensure_node(other)
        result = Node(self.data / other.data, [self, other], 'div')
        
        def _backward():
            if self.requires_grad:
                self.grad += result.grad / other.data
            if other.requires_grad:
                other.grad -= result.grad * self.data / (other.data ** 2)
        
        result._backward_fn = _backward
        return result
    
    def __pow__(self, power: Union['Node', float]) -> 'Node':
        """عملية الأس"""
        if isinstance(power, (int, float)):
            result = Node(self.data ** power, [self], f'pow_{power}')
            
            def _backward():
                if self.requires_grad:
                    self.grad += power * (self.data ** (power - 1)) * result.grad
            
            result._backward_fn = _backward
            return result
        else:
            # للأسس المتغيرة
            power = self._ensure_node(power)
            result = Node(self.data ** power.data, [self, power], 'pow')
            
            def _backward():
                if self.requires_grad:
                    self.grad += power.data * (self.data ** (power.data - 1)) * result.grad
                if power.requires_grad:
                    power.grad += np.log(self.data) * result.data * result.grad
            
            result._backward_fn = _backward
            return result
    
    def __neg__(self) -> 'Node':
        """عملية النفي"""
        result = Node(-self.data, [self], 'neg')
        
        def _backward():
            if self.requires_grad:
                self.grad -= result.grad
        
        result._backward_fn = _backward
        return result
    
    # دوال التفعيل
    def relu(self) -> 'Node':
        """دالة ReLU"""
        result = Node(np.maximum(0, self.data), [self], 'relu')
        
        def _backward():
            if self.requires_grad:
                self.grad += (self.data > 0) * result.grad
        
        result._backward_fn = _backward
        return result
    
    def sigmoid(self) -> 'Node':
        """دالة Sigmoid"""
        sigmoid_data = 1 / (1 + np.exp(-np.clip(self.data, -500, 500)))
        result = Node(sigmoid_data, [self], 'sigmoid')
        
        def _backward():
            if self.requires_grad:
                self.grad += sigmoid_data * (1 - sigmoid_data) * result.grad
        
        result._backward_fn = _backward
        return result
    
    def tanh(self) -> 'Node':
        """دالة Tanh"""
        tanh_data = np.tanh(self.data)
        result = Node(tanh_data, [self], 'tanh')
        
        def _backward():
            if self.requires_grad:
                self.grad += (1 - tanh_data ** 2) * result.grad
        
        result._backward_fn = _backward
        return result
    
    def softmax(self, axis: int = -1) -> 'Node':
        """دالة Softmax"""
        # تطبيق الاستقرار العددي
        shifted = self.data - np.max(self.data, axis=axis, keepdims=True)
        exp_data = np.exp(shifted)
        softmax_data = exp_data / np.sum(exp_data, axis=axis, keepdims=True)
        result = Node(softmax_data, [self], 'softmax')
        
        def _backward():
            if self.requires_grad:
                # تدرج Softmax معقد قليلاً
                s = softmax_data
                grad_input = s * result.grad
                grad_input -= s * np.sum(s * result.grad, axis=axis, keepdims=True)
                self.grad += grad_input
        
        result._backward_fn = _backward
        return result
    
    # عمليات المصفوفات
    def matmul(self, other: 'Node') -> 'Node':
        """ضرب المصفوفات"""
        other = self._ensure_node(other)
        result = Node(np.matmul(self.data, other.data), [self, other], 'matmul')
        
        def _backward():
            if self.requires_grad:
                self.grad += np.matmul(result.grad, other.data.T)
            if other.requires_grad:
                other.grad += np.matmul(self.data.T, result.grad)
        
        result._backward_fn = _backward
        return result
    
    def sum(self, axis: Optional[Union[int, Tuple[int, ...]]] = None, 
            keepdims: bool = False) -> 'Node':
        """مجموع العناصر"""
        result = Node(np.sum(self.data, axis=axis, keepdims=keepdims), [self], 'sum')
        
        def _backward():
            if self.requires_grad:
                if axis is None:
                    self.grad += np.ones_like(self.data) * result.grad
                else:
                    grad_shape = list(self.data.shape)
                    if isinstance(axis, int):
                        axis_tuple = (axis,)
                    else:
                        axis_tuple = axis
                    
                    if not keepdims:
                        for ax in sorted(axis_tuple):
                            grad_shape[ax] = 1
                        expanded_grad = result.grad.reshape(grad_shape)
                    else:
                        expanded_grad = result.grad
                    
                    self.grad += np.broadcast_to(expanded_grad, self.data.shape)
        
        result._backward_fn = _backward
        return result
    
    def mean(self, axis: Optional[Union[int, Tuple[int, ...]]] = None, 
             keepdims: bool = False) -> 'Node':
        """متوسط العناصر"""
        if axis is None:
            n = self.data.size
        else:
            if isinstance(axis, int):
                n = self.data.shape[axis]
            else:
                n = np.prod([self.data.shape[ax] for ax in axis])
        
        return self.sum(axis=axis, keepdims=keepdims) / n
    
    def reshape(self, shape: Tuple[int, ...]) -> 'Node':
        """إعادة تشكيل المصفوفة"""
        result = Node(self.data.reshape(shape), [self], 'reshape')
        
        def _backward():
            if self.requires_grad:
                self.grad += result.grad.reshape(self.data.shape)
        
        result._backward_fn = _backward
        return result
    
    def transpose(self, axes: Optional[Tuple[int, ...]] = None) -> 'Node':
        """نقل المصفوفة"""
        result = Node(np.transpose(self.data, axes), [self], 'transpose')
        
        def _backward():
            if self.requires_grad:
                if axes is None:
                    self.grad += result.grad.T
                else:
                    # إنشاء الترتيب العكسي
                    inv_axes = np.argsort(axes)
                    self.grad += np.transpose(result.grad, inv_axes)
        
        result._backward_fn = _backward
        return result
    
    # دوال الخسارة
    def mse_loss(self, target: 'Node') -> 'Node':
        """دالة خسارة متوسط مربع الخطأ"""
        target = self._ensure_node(target)
        diff = self - target
        return (diff * diff).mean()
    
    def cross_entropy_loss(self, target: 'Node') -> 'Node':
        """دالة خسارة Cross Entropy"""
        target = self._ensure_node(target)
        # تطبيق log-softmax للاستقرار العددي
        log_probs = self - self.max(axis=-1, keepdims=True)
        log_probs = log_probs - log_probs.exp().sum(axis=-1, keepdims=True).log()
        return -(target * log_probs).sum(axis=-1).mean()
    
    def max(self, axis: Optional[int] = None, keepdims: bool = False) -> 'Node':
        """القيمة العظمى"""
        result = Node(np.max(self.data, axis=axis, keepdims=keepdims), [self], 'max')
        
        def _backward():
            if self.requires_grad:
                if axis is None:
                    mask = (self.data == result.data)
                    self.grad += mask * result.grad / np.sum(mask)
                else:
                    expanded_result = np.expand_dims(result.data, axis) if not keepdims else result.data
                    mask = (self.data == expanded_result)
                    expanded_grad = np.expand_dims(result.grad, axis) if not keepdims else result.grad
                    self.grad += mask * expanded_grad
        
        result._backward_fn = _backward
        return result
    
    def exp(self) -> 'Node':
        """دالة الأس الطبيعي"""
        exp_data = np.exp(np.clip(self.data, -500, 500))
        result = Node(exp_data, [self], 'exp')
        
        def _backward():
            if self.requires_grad:
                self.grad += exp_data * result.grad
        
        result._backward_fn = _backward
        return result
    
    def log(self) -> 'Node':
        """دالة اللوغاريتم الطبيعي"""
        log_data = np.log(np.clip(self.data, 1e-8, None))
        result = Node(log_data, [self], 'log')
        
        def _backward():
            if self.requires_grad:
                self.grad += result.grad / np.clip(self.data, 1e-8, None)
        
        result._backward_fn = _backward
        return result
    
    # الانتشار الخلفي
    def backward(self) -> None:
        """تنفيذ الانتشار الخلفي"""
        if not self.requires_grad:
            return
        
        # إعداد التدرج الأولي
        if self.grad is None:
            self.grad = np.ones_like(self.data)
        
        # ترتيب طوبولوجي للعقد
        visited = set()
        topo_order = []
        
        def build_topo(node):
            if node._id not in visited:
                visited.add(node._id)
                for child in node.children:
                    build_topo(child)
                topo_order.append(node)
        
        build_topo(self)
        
        # تنفيذ الانتشار الخلفي
        for node in reversed(topo_order):
            if node._backward_fn:
                node._backward_fn()
    
    def zero_grad(self) -> None:
        """إعادة تعيين التدرجات إلى الصفر"""
        if self.requires_grad and self.grad is not None:
            self.grad.fill(0)
    
    def detach(self) -> 'Node':
        """فصل العقدة عن الرسم البياني للتدرج"""
        return Node(self.data.copy(), requires_grad=False)
    
    def item(self) -> float:
        """استخراج قيمة عددية واحدة"""
        if self.data.size != 1:
            raise ValueError("item() can only be called on single-element tensors")
        return float(self.data.item())
    
    @property
    def shape(self) -> Tuple[int, ...]:
        """شكل البيانات"""
        return self.data.shape
    
    @property
    def ndim(self) -> int:
        """عدد الأبعاد"""
        return self.data.ndim
    
    @property
    def size(self) -> int:
        """العدد الكلي للعناصر"""
        return self.data.size
    
    def _ensure_node(self, other: Union['Node', float, np.ndarray]) -> 'Node':
        """تحويل القيم إلى عقد إذا لزم الأمر"""
        if not isinstance(other, Node):
            return Node(other, requires_grad=False)
        return other

# دوال مساعدة للإنشاء
def zeros(shape: Tuple[int, ...], requires_grad: bool = True) -> Node:
    """إنشاء عقدة مليئة بالأصفار"""
    return Node(np.zeros(shape), requires_grad=requires_grad)

def ones(shape: Tuple[int, ...], requires_grad: bool = True) -> Node:
    """إنشاء عقدة مليئة بالواحدات"""
    return Node(np.ones(shape), requires_grad=requires_grad)

def randn(shape: Tuple[int, ...], requires_grad: bool = True) -> Node:
    """إنشاء عقدة بقيم عشوائية من التوزيع الطبيعي"""
    return Node(np.random.randn(*shape), requires_grad=requires_grad)

def rand(shape: Tuple[int, ...], requires_grad: bool = True) -> Node:
    """إنشاء عقدة بقيم عشوائية موحدة"""
    return Node(np.random.rand(*shape), requires_grad=requires_grad)

def tensor(data: Union[float, List, np.ndarray], requires_grad: bool = True) -> Node:
    """إنشاء عقدة من البيانات"""
    return Node(data, requires_grad=requires_grad)

# اختبار سريع
if __name__ == "__main__":
    # اختبار العمليات الأساسية
    x = tensor([2.0, 3.0], requires_grad=True)
    y = tensor([1.0, 4.0], requires_grad=True)
    
    z = x * y + x ** 2
    loss = z.sum()
    
    print(f"x: {x}")
    print(f"y: {y}")
    print(f"z: {z}")
    print(f"loss: {loss}")
    
    loss.backward()
    
    print(f"x.grad: {x.grad}")
    print(f"y.grad: {y.grad}")
    
    logger.info("اختبار محرك التفاضل التلقائي مكتمل بنجاح!")
