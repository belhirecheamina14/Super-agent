"""
Manus DL - Complete Improved Engine

This is a single-file experimental deep-learning/autodiff engine implemented
for clarity and hands-on tinkering in Colab or local Python.

Features:
- Node-based autodiff with topological backward
- float64 gradient accumulation toggle
- Parameter and Module abstractions
- Layers: Linear, ReLU, Softmax
- Sequential container
- Losses: MSELoss and SoftmaxCrossEntropyLoss
- Optimizers: SGD (with momentum/weight decay) and Adam
- Gradient clipping utility
- Simple NumpyDataset and DataLoader
- Training helpers and save/load utilities
- Small demo in __main__

This file is intended to be a practical, self-contained baseline you can
copy into Google Colab and experiment with. It's written for readability
(rather than raw performance).
"""

from __future__ import annotations
import numpy as np
import math
import pickle
from typing import Any, Dict, Iterable, List, Optional, Tuple

# ------------------------- Config ---------------------------------------
# Toggle: use float64 internal accumulation for stability
ENABLE_HIGH_PRECISION_ACCUMULATION: bool = True

# ------------------------- Utilities ------------------------------------

def set_seed(seed: int):
    np.random.seed(seed)


def _sum_to_shape(arr: np.ndarray, shape: Tuple[int, ...]) -> np.ndarray:
    """Reduce `arr` to `shape` by summation across broadcasted axes.
    This handles leading/trailing broadcast dims conservatively.
    """
    arr = np.asarray(arr)
    if arr.shape == shape:
        return arr
    # reduce leading dims
    while arr.ndim > len(shape):
        arr = arr.sum(axis=0)
    # reduce axes where target has size 1
    for i, (a_dim, s_dim) in enumerate(zip(arr.shape, shape)):
        if s_dim == 1 and a_dim != 1:
            arr = arr.sum(axis=i, keepdims=True)
    if arr.shape != shape:
        try:
            arr = arr.reshape(shape)
        except Exception:
            # Last resort: broadcast then sum
            arr = np.broadcast_to(arr, shape)
    return arr


# ------------------------- Autodiff Node -------------------------------
class Node:
    def __init__(self,
                 value: Any,
                 parents: Tuple['Node', ...] = (),
                 op: str = '',
                 name: Optional[str] = None,
                 is_param: bool = False):
        # normalize value to numpy array (float32)
        if isinstance(value, np.ndarray):
            self.value = value.astype(np.float32)
        else:
            self.value = np.array(value, dtype=np.float32)

        self.parents: Tuple[Node, ...] = tuple(parents)
        self.op = op
        self.name = name or op or f'Node_{id(self)}'
        self.is_param = is_param

        # public gradient view (dtype same as value)
        self.grad: Optional[np.ndarray] = None
        # internal accumulation buffer (float64) for stability if enabled
        self._grad_accum: Optional[np.ndarray] = None
        self._backward = lambda: None

    def __repr__(self):
        return f"Node(name={self.name!r}, op={self.op!r}, shape={self.value.shape})"

    # ---- arithmetic helpers ----
    def _ensure_node(self, other: Any) -> 'Node':
        return other if isinstance(other, Node) else Node(other, (), 'const')

    def _accumulate_grad(self, grad: np.ndarray):
        grad = np.asarray(grad)
        # reduce to the node shape first
        g = _sum_to_shape(grad, self.value.shape)
        if ENABLE_HIGH_PRECISION_ACCUMULATION:
            if self._grad_accum is None:
                self._grad_accum = np.zeros_like(self.value, dtype=np.float64)
            self._grad_accum += g.astype(np.float64)
            self.grad = self._grad_accum.astype(self.value.dtype)
        else:
            if self.grad is None:
                self.grad = np.zeros_like(self.value, dtype=self.value.dtype)
            self.grad += g.astype(self.value.dtype)

    # binary ops
    def __add__(self, other: Any) -> 'Node':
        other = self._ensure_node(other)
        out = Node(self.value + other.value, (self, other), 'add')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad(out.grad)
            other._accumulate_grad(out.grad)
        out._backward = _backward
        return out

    def __radd__(self, other: Any) -> 'Node':
        return self.__add__(other)

    def __sub__(self, other: Any) -> 'Node':
        other = self._ensure_node(other)
        out = Node(self.value - other.value, (self, other), 'sub')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad(out.grad)
            other._accumulate_grad(-out.grad)
        out._backward = _backward
        return out

    def __neg__(self) -> 'Node':
        out = Node(-self.value, (self,), 'neg')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad(-out.grad)
        out._backward = _backward
        return out

    def __mul__(self, other: Any) -> 'Node':
        other = self._ensure_node(other)
        out = Node(self.value * other.value, (self, other), 'mul')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad(out.grad * other.value)
            other._accumulate_grad(out.grad * self.value)
        out._backward = _backward
        return out

    def __rmul__(self, other: Any) -> 'Node':
        return self.__mul__(other)

    def __truediv__(self, other: Any) -> 'Node':
        other = self._ensure_node(other)
        out = Node(self.value / other.value, (self, other), 'div')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad(out.grad / other.value)
            other._accumulate_grad(-out.grad * self.value / (other.value ** 2))
        out._backward = _backward
        return out

    def __matmul__(self, other: Any) -> 'Node':
        other = self._ensure_node(other)
        out = Node(self.value @ other.value, (self, other), 'matmul')
        def _backward():
            if out.grad is None:
                return
            # out.grad shape (batch, out_features)
            self._accumulate_grad(out.grad @ other.value.T)
            other._accumulate_grad(self.value.T @ out.grad)
        out._backward = _backward
        return out

    def __pow__(self, power: float) -> 'Node':
        out = Node(self.value ** power, (self,), f'pow_{power}')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad((power * (self.value ** (power - 1))) * out.grad)
        out._backward = _backward
        return out

    # ---- elementwise activations ----
    def relu(self) -> 'Node':
        out = Node(np.maximum(0.0, self.value), (self,), 'relu')
        def _backward():
            if out.grad is None:
                return
            mask = (self.value > 0).astype(np.float32)
            self._accumulate_grad(mask * out.grad)
        out._backward = _backward
        return out

    def sigmoid(self) -> 'Node':
        x = np.clip(self.value, -500, 500)
        s = 1.0 / (1.0 + np.exp(-x))
        out = Node(s, (self,), 'sigmoid')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad((s * (1 - s)) * out.grad)
        out._backward = _backward
        return out

    def tanh(self) -> 'Node':
        t = np.tanh(self.value)
        out = Node(t, (self,), 'tanh')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad((1 - t * t) * out.grad)
        out._backward = _backward
        return out

    def exp(self) -> 'Node':
        x = np.clip(self.value, -100, 100)
        e = np.exp(x)
        out = Node(e, (self,), 'exp')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad(e * out.grad)
        out._backward = _backward
        return out

    def log(self) -> 'Node':
        safe = np.maximum(self.value, 1e-15)
        l = np.log(safe)
        out = Node(l, (self,), 'log')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad((1.0 / safe) * out.grad)
        out._backward = _backward
        return out

    # ---- reductions and reshape ----
    def sum(self, axis=None, keepdims=False) -> 'Node':
        val = self.value.sum(axis=axis, keepdims=keepdims)
        out = Node(val, (self,), 'sum')
        def _backward():
            if out.grad is None:
                return
            g = out.grad
            if axis is None:
                g2 = np.broadcast_to(g, self.value.shape)
            else:
                if not keepdims:
                    if isinstance(axis, int):
                        g = np.expand_dims(g, axis)
                    else:
                        for ax in sorted(axis):
                            g = np.expand_dims(g, ax)
                g2 = np.broadcast_to(g, self.value.shape)
            self._accumulate_grad(g2)
        out._backward = _backward
        return out

    def mean(self, axis=None, keepdims=False) -> 'Node':
        val = self.value.mean(axis=axis, keepdims=keepdims)
        out = Node(val, (self,), 'mean')
        def _backward():
            if out.grad is None:
                return
            if axis is None:
                denom = self.value.size
            else:
                if isinstance(axis, int):
                    denom = self.value.shape[axis]
                else:
                    denom = int(np.prod([self.value.shape[a] for a in axis]))
            g = out.grad / denom
            if axis is not None and not keepdims:
                if isinstance(axis, int):
                    g = np.expand_dims(g, axis)
                else:
                    for ax in sorted(axis):
                        g = np.expand_dims(g, ax)
            g2 = np.broadcast_to(g, self.value.shape)
            self._accumulate_grad(g2)
        out._backward = _backward
        return out

    def reshape(self, *shape) -> 'Node':
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = shape[0]
        val = self.value.reshape(*shape)
        out = Node(val, (self,), 'reshape')
        def _backward():
            if out.grad is None:
                return
            self._accumulate_grad(out.grad.reshape(self.value.shape))
        out._backward = _backward
        return out

    def transpose(self, axes=None) -> 'Node':
        val = self.value.transpose(axes) if axes is not None else self.value.T
        out = Node(val, (self,), 'transpose')
        def _backward():
            if out.grad is None:
                return
            if axes is None:
                g = out.grad.T
            else:
                inv = np.argsort(axes)
                g = out.grad.transpose(inv)
            self._accumulate_grad(g)
        out._backward = _backward
        return out

    def softmax(self, axis: int = -1) -> 'Node':
        maxv = np.max(self.value, axis=axis, keepdims=True)
        exps = np.exp(self.value - maxv)
        probs = exps / np.sum(exps, axis=axis, keepdims=True)
        out = Node(probs, (self,), 'softmax')
        def _backward():
            if out.grad is None:
                return
            g = out.grad
            s = probs
            if s.ndim == 2:
                batch = s.shape[0]
                gin = np.empty_like(s)
                for i in range(batch):
                    si = s[i:i+1]
                    gi = g[i:i+1]
                    inner = (gi * si).sum(axis=1, keepdims=True)
                    gin[i:i+1] = (gi - inner) * si
            else:
                inner = (g * s).sum()
                gin = (g - inner) * s
            self._accumulate_grad(gin)
        out._backward = _backward
        return out

    # ---- topo/backward execution ----
    def _build_topo(self, visited=None) -> List['Node']:
        if visited is None:
            visited = set()
        topo: List[Node] = []
        def build(node: 'Node'):
            if id(node) in visited:
                return
            visited.add(id(node))
            for p in node.parents:
                build(p)
            topo.append(node)
        build(self)
        return topo

    def backward(self):
        topo = self._build_topo()
        # reset grads
        for n in topo:
            n.grad = None
            if ENABLE_HIGH_PRECISION_ACCUMULATION:
                n._grad_accum = np.zeros_like(n.value, dtype=np.float64)
        # seed gradient
        self.grad = np.ones_like(self.value, dtype=self.value.dtype)
        if ENABLE_HIGH_PRECISION_ACCUMULATION:
            self._grad_accum = self.grad.astype(np.float64)
        # execute
        for node in reversed(topo):
            try:
                node._backward()
            except Exception as e:
                print(f"Warning: backward failed for node {node}: {e}")

    def zero_grad(self):
        self.grad = None
        self._grad_accum = None


# ------------------------- Parameter & Module --------------------------
class Parameter(Node):
    def __init__(self, value: Any, name: Optional[str] = None):
        super().__init__(value, (), 'param', name or 'param')
        self.is_param = True

class Module:
    def __init__(self):
        self._modules: Dict[str, Module] = {}
        self._parameters: Dict[str, Parameter] = {}

    def add_module(self, name: str, module: 'Module') -> 'Module':
        self._modules[name] = module
        return module

    def add_parameter(self, name: str, value: Any) -> Parameter:
        p = Parameter(value, name)
        self._parameters[name] = p
        return p

    def parameters(self) -> List[Parameter]:
        res: List[Parameter] = []
        for p in self._parameters.values():
            res.append(p)
        for m in self._modules.values():
            res.extend(m.parameters())
        return res

    def zero_grad(self):
        for p in self.parameters():
            p.zero_grad()

    def state_dict(self) -> Dict[str, Any]:
        sd: Dict[str, Any] = {}
        for k, p in self._parameters.items():
            sd[k] = p.value.copy()
        for k, m in self._modules.items():
            sd[k] = m.state_dict()
        return sd

    def load_state_dict(self, sd: Dict[str, Any]):
        for k, v in sd.items():
            if k in self._parameters:
                self._parameters[k].value = np.array(v, dtype=np.float32)
            elif k in self._modules:
                self._modules[k].load_state_dict(v)

    def train(self):
        self._training = True

    def eval(self):
        self._training = False


# ------------------------- Layers --------------------------------------
class Linear(Module):
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        limit = math.sqrt(6.0 / (in_features + out_features))
        w = np.random.uniform(-limit, limit, size=(in_features, out_features)).astype(np.float32)
        self.weight = self.add_parameter('weight', w)
        self.bias = None
        if bias:
            b = np.zeros((out_features,), dtype=np.float32)
            self.bias = self.add_parameter('bias', b)

    def __call__(self, x: Node) -> Node:
        out_val = x.value @ self.weight.value
        if self.bias is not None:
            out_val = out_val + self.bias.value
        out = Node(out_val, (x, self.weight) if self.bias is None else (x, self.weight, self.bias), 'linear')
        def _backward():
            if out.grad is None:
                return
            g = out.grad
            # grad w.r.t input
            x._accumulate_grad(g @ self.weight.value.T)
            # grad w.r.t weight
            dw = x.value.T @ g
            self.weight._accumulate_grad(dw)
            if self.bias is not None:
                db = g.sum(axis=0)
                self.bias._accumulate_grad(db)
        out._backward = _backward
        return out

class ReLU(Module):
    def __call__(self, x: Node) -> Node:
        return x.relu()

class Softmax(Module):
    def __init__(self, axis: int = -1):
        super().__init__()
        self.axis = axis
    def __call__(self, x: Node) -> No
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)