"""
طبقات الشبكات العصبية للنظام الموحد
Neural Network Layers for Unified System

تتضمن:
- الطبقات الخطية
- طبقات التطبيع
- الطبقات الالتفافية
- طبقات التجميع
"""

import numpy as np
from typing import Optional, Tuple, Union, List
from .node_fixed import Node, tensor, zeros, ones, randn
import logging

logger = logging.getLogger(__name__)

class Layer:
    """الفئة الأساسية لجميع الطبقات"""
    
    def __init__(self):
        self.training = True
        self.parameters = []
    
    def __call__(self, x: Node) -> Node:
        return self.forward(x)
    
    def forward(self, x: Node) -> Node:
        raise NotImplementedError
    
    def train(self):
        """تعيين الطبقة في وضع التدريب"""
        self.training = True
    
    def eval(self):
        """تعيين الطبقة في وضع التقييم"""
        self.training = False
    
    def get_parameters(self) -> List[Node]:
        """الحصول على جميع المعاملات القابلة للتدريب"""
        return self.parameters

class Linear(Layer):
    """الطبقة الخطية (Dense/Fully Connected)"""
    
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.use_bias = bias
        
        # تهيئة الأوزان باستخدام Xavier/Glorot
        std = np.sqrt(2.0 / (in_features + out_features))
        self.weight = randn((in_features, out_features)) * std
        
        if bias:
            self.bias = zeros((out_features,))
        else:
            self.bias = None
        
        # إضافة المعاملات إلى القائمة
        self.parameters = [self.weight]
        if self.bias is not None:
            self.parameters.append(self.bias)
    
    def forward(self, x: Node) -> Node:
        """التمرير الأمامي للطبقة الخطية"""
        # x: (batch_size, in_features)
        # weight: (in_features, out_features)
        # output: (batch_size, out_features)
        
        output = x.matmul(self.weight)
        
        if self.bias is not None:
            # إضافة bias مع التعامل مع broadcasting
            bias_expanded = self.bias.reshape((1, -1))  # (1, out_features)
            output = output + bias_expanded
        
        return output
    
    def __repr__(self):
        return f"Linear(in_features={self.in_features}, out_features={self.out_features}, bias={self.use_bias})"

class ReLU(Layer):
    """طبقة تفعيل ReLU"""
    
    def forward(self, x: Node) -> Node:
        return x.relu()
    
    def __repr__(self):
        return "ReLU()"

class Sigmoid(Layer):
    """طبقة تفعيل Sigmoid"""
    
    def forward(self, x: Node) -> Node:
        return x.sigmoid()
    
    def __repr__(self):
        return "Sigmoid()"

class Tanh(Layer):
    """طبقة تفعيل Tanh"""
    
    def forward(self, x: Node) -> Node:
        return x.tanh()
    
    def __repr__(self):
        return "Tanh()"

class Softmax(Layer):
    """طبقة تفعيل Softmax"""
    
    def __init__(self, axis: int = -1):
        super().__init__()
        self.axis = axis
    
    def forward(self, x: Node) -> Node:
        return x.softmax(axis=self.axis)
    
    def __repr__(self):
        return f"Softmax(axis={self.axis})"

class Dropout(Layer):
    """طبقة Dropout للتنظيم"""
    
    def __init__(self, p: float = 0.5):
        super().__init__()
        self.p = p
    
    def forward(self, x: Node) -> Node:
        if not self.training:
            return x
        
        # إنشاء قناع عشوائي
        keep_prob = 1.0 - self.p
        mask = np.random.binomial(1, keep_prob, x.shape) / keep_prob
        mask_node = tensor(mask, requires_grad=False)
        
        return x * mask_node
    
    def __repr__(self):
        return f"Dropout(p={self.p})"

class BatchNorm1d(Layer):
    """طبقة التطبيع المجمعي أحادية البعد"""
    
    def __init__(self, num_features: int, eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        self.num_features = num_features
        self.eps = eps
        self.momentum = momentum
        
        # معاملات قابلة للتعلم
        self.weight = ones((num_features,))
        self.bias = zeros((num_features,))
        
        # إحصائيات التشغيل
        self.running_mean = np.zeros(num_features)
        self.running_var = np.ones(num_features)
        
        self.parameters = [self.weight, self.bias]
    
    def forward(self, x: Node) -> Node:
        # x: (batch_size, num_features)
        
        if self.training:
            # حساب المتوسط والتباين للدفعة الحالية
            batch_mean = x.mean(axis=0)
            batch_var = ((x - batch_mean) ** 2).mean(axis=0)
            
            # تحديث إحصائيات التشغيل
            self.running_mean = (1 - self.momentum) * self.running_mean + self.momentum * batch_mean.data
            self.running_var = (1 - self.momentum) * self.running_var + self.momentum * batch_var.data
            
            # التطبيع
            normalized = (x - batch_mean) / ((batch_var + self.eps) ** 0.5)
        else:
            # استخدام إحصائيات التشغيل في وضع التقييم
            running_mean_node = tensor(self.running_mean, requires_grad=False)
            running_var_node = tensor(self.running_var, requires_grad=False)
            normalized = (x - running_mean_node) / ((running_var_node + self.eps) ** 0.5)
        
        # تطبيق التحويل الخطي
        return normalized * self.weight + self.bias
    
    def __repr__(self):
        return f"BatchNorm1d(num_features={self.num_features}, eps={self.eps}, momentum={self.momentum})"

class Conv2d(Layer):
    """طبقة التطبيق الالتفافي ثنائية الأبعاد"""
    
    def __init__(self, in_channels: int, out_channels: int, kernel_size: Union[int, Tuple[int, int]], 
                 stride: Union[int, Tuple[int, int]] = 1, padding: Union[int, Tuple[int, int]] = 0, bias: bool = True):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        
        # تحويل kernel_size و stride و padding إلى tuples
        if isinstance(kernel_size, int):
            self.kernel_size = (kernel_size, kernel_size)
        else:
            self.kernel_size = kernel_size
        
        if isinstance(stride, int):
            self.stride = (stride, stride)
        else:
            self.stride = stride
        
        if isinstance(padding, int):
            self.padding = (padding, padding)
        else:
            self.padding = padding
        
        self.use_bias = bias
        
        # تهيئة الأوزان
        fan_in = in_channels * self.kernel_size[0] * self.kernel_size[1]
        fan_out = out_channels * self.kernel_size[0] * self.kernel_size[1]
        std = np.sqrt(2.0 / (fan_in + fan_out))
        
        self.weight = randn((out_channels, in_channels, self.kernel_size[0], self.kernel_size[1])) * std
        
        if bias:
            self.bias = zeros((out_channels,))
        else:
            self.bias = None
        
        self.parameters = [self.weight]
        if self.bias is not None:
            self.parameters.append(self.bias)
    
    def forward(self, x: Node) -> Node:
        """التمرير الأمامي للطبقة الالتفافية"""
        # x: (batch_size, in_channels, height, width)
        # weight: (out_channels, in_channels, kernel_h, kernel_w)
        
        batch_size, in_channels, in_height, in_width = x.shape
        out_channels, _, kernel_h, kernel_w = self.weight.shape
        
        # حساب أبعاد الخرج
        out_height = (in_height + 2 * self.padding[0] - kernel_h) // self.stride[0] + 1
        out_width = (in_width + 2 * self.padding[1] - kernel_w) // self.stride[1] + 1
        
        # تطبيق padding إذا لزم الأمر
        if self.padding[0] > 0 or self.padding[1] > 0:
            x_padded = self._pad(x)
        else:
            x_padded = x
        
        # تنفيذ التطبيق الالتفافي باستخدام im2col
        output = self._conv2d_forward(x_padded, self.weight, out_height, out_width)
        
        if self.bias is not None:
            # إضافة bias: (out_channels,) -> (1, out_channels, 1, 1)
            bias_reshaped = self.bias.reshape((1, out_channels, 1, 1))
            output = output + bias_reshaped
        
        return output
    
    def _pad(self, x: Node) -> Node:
        """تطبيق padding على المدخل"""
        pad_h, pad_w = self.padding
        batch_size, channels, height, width = x.shape
        
        # إنشاء مصفوفة مبطنة
        padded_data = np.zeros((batch_size, channels, height + 2*pad_h, width + 2*pad_w))
        padded_data[:, :, pad_h:height+pad_h, pad_w:width+pad_w] = x.data
        
        padded = Node(padded_data, [x], 'pad')
        
        def _backward():
            if x.requires_grad:
                x.grad += padded.grad[:, :, pad_h:height+pad_h, pad_w:width+pad_w]
        
        padded._backward_fn = _backward
        return padded
    
    def _conv2d_forward(self, x: Node, weight: Node, out_height: int, out_width: int) -> Node:
        """تنفيذ التطبيق الالتفافي الأمامي"""
        batch_size, in_channels, in_height, in_width = x.shape
        out_channels, _, kernel_h, kernel_w = weight.shape
        
        # إنشاء مصفوفة الخرج
        output_data = np.zeros((batch_size, out_channels, out_height, out_width))
        
        # تنفيذ التطبيق الالتفافي
        for b in range(batch_size):
            for oc in range(out_channels):
                for oh in range(out_height):
                    for ow in range(out_width):
                        h_start = oh * self.stride[0]
                        h_end = h_start + kernel_h
                        w_start = ow * self.stride[1]
                        w_end = w_start + kernel_w
                        
                        # استخراج النافذة
                        window = x.data[b, :, h_start:h_end, w_start:w_end]
                        # ضرب بالمرشح
                        output_data[b, oc, oh, ow] = np.sum(window * weight.data[oc])
        
        result = Node(output_data, [x, weight], 'conv2d')
        
        def _backward():
            if x.requires_grad:
                # تدرج المدخل
                x_grad = np.zeros_like(x.data)
                for b in range(batch_size):
                    for oc in range(out_channels):
                        for oh in range(out_height):
                            for ow in range(out_width):
                                h_start = oh * self.stride[0]
                                h_end = h_start + kernel_h
                                w_start = ow * self.stride[1]
                                w_end = w_start + kernel_w
                                
                                x_grad[b, :, h_start:h_end, w_start:w_end] += \
                                    weight.data[oc] * result.grad[b, oc, oh, ow]
                
                x.grad += x_grad
            
            if weight.requires_grad:
                # تدرج الأوزان
                weight_grad = np.zeros_like(weight.data)
                for b in range(batch_size):
                    for oc in range(out_channels):
                        for oh in range(out_height):
                            for ow in range(out_width):
                                h_start = oh * self.stride[0]
                                h_end = h_start + kernel_h
                                w_start = ow * self.stride[1]
                                w_end = w_start + kernel_w
                                
                                window = x.data[b, :, h_start:h_end, w_start:w_end]
                                weight_grad[oc] += window * result.grad[b, oc, oh, ow]
                
                weight.grad += weight_grad
        
        result._backward_fn = _backward
        return result
    
    def __repr__(self):
        return f"Conv2d(in_channels={self.in_channels}, out_channels={self.out_channels}, " \
               f"kernel_size={self.kernel_size}, stride={self.stride}, padding={self.padding}, bias={self.use_bias})"

class MaxPool2d(Layer):
    """طبقة التجميع الأعظمي ثنائية الأبعاد"""
    
    def __init__(self, kernel_size: Union[int, Tuple[int, int]], 
                 stride: Optional[Union[int, Tuple[int, int]]] = None):
        super().__init__()
        
        if isinstance(kernel_size, int):
            self.kernel_size = (kernel_size, kernel_size)
        else:
            self.kernel_size = kernel_size
        
        if stride is None:
            self.stride = self.kernel_size
        elif isinstance(stride, int):
            self.stride = (stride, stride)
        else:
            self.stride = stride
    
    def forward(self, x: Node) -> Node:
        """التمرير الأمامي لطبقة التجميع الأعظمي"""
        batch_size, channels, in_height, in_width = x.shape
        kernel_h, kernel_w = self.kernel_size
        stride_h, stride_w = self.stride
        
        # حساب أبعاد الخرج
        out_height = (in_height - kernel_h) // stride_h + 1
        out_width = (in_width - kernel_w) // stride_w + 1
        
        # إنشاء مصفوفة الخرج ومصفوفة المؤشرات
        output_data = np.zeros((batch_size, channels, out_height, out_width))
        max_indices = np.zeros((batch_size, channels, out_height, out_width, 2), dtype=int)
        
        # تنفيذ MaxPooling
        for b in range(batch_size):
            for c in range(channels):
                for oh in range(out_height):
                    for ow in range(out_width):
                        h_start = oh * stride_h
                        h_end = h_start + kernel_h
                        w_start = ow * stride_w
                        w_end = w_start + kernel_w
                        
                        # استخراج النافذة
                        window = x.data[b, c, h_start:h_end, w_start:w_end]
                        
                        # العثور على القيمة العظمى والمؤشر
                        max_val = np.max(window)
                        max_idx = np.unravel_index(np.argmax(window), window.shape)
                        
                        output_data[b, c, oh, ow] = max_val
                        max_indices[b, c, oh, ow] = [h_start + max_idx[0], w_start + max_idx[1]]
        
        result = Node(output_data, [x], 'maxpool2d')
        
        def _backward():
            if x.requires_grad:
                x_grad = np.zeros_like(x.data)
                for b in range(batch_size):
                    for c in range(channels):
                        for oh in range(out_height):
                            for ow in range(out_width):
                                max_h, max_w = max_indices[b, c, oh, ow]
                                x_grad[b, c, max_h, max_w] += result.grad[b, c, oh, ow]
                
                x.grad += x_grad
        
        result._backward_fn = _backward
        return result
    
    def __repr__(self):
        return f"MaxPool2d(kernel_size={self.kernel_size}, stride={self.stride})"

class Sequential(Layer):
    """حاوية تسلسلية للطبقات"""
    
    def __init__(self, *layers):
        super().__init__()
        self.layers = list(layers)
        
        # جمع جميع المعاملات
        self.parameters = []
        for layer in self.layers:
            if hasattr(layer, 'parameters'):
                self.parameters.extend(layer.parameters)
    
    def forward(self, x: Node) -> Node:
        """التمرير الأمامي عبر جميع الطبقات"""
        for layer in self.layers:
            x = layer(x)
        return x
    
    def train(self):
        """تعيين جميع الطبقات في وضع التدريب"""
        super().train()
        for layer in self.layers:
            layer.train()
    
    def eval(self):
        """تعيين جميع الطبقات في وضع التقييم"""
        super().eval()
        for layer in self.layers:
            layer.eval()
    
    def add(self, layer: Layer):
        """إضافة طبقة جديدة"""
        self.layers.append(layer)
        if hasattr(layer, 'parameters'):
            self.parameters.extend(layer.parameters)
    
    def __repr__(self):
        layer_strs = [f"  ({i}): {layer}" for i, layer in enumerate(self.layers)]
        return f"Sequential(\n" + "\n".join(layer_strs) + "\n)"

# اختبار سريع
if __name__ == "__main__":
    # اختبار الطبقة الخطية
    linear = Linear(10, 5)
    x = randn((3, 10))
    y = linear(x)
    print(f"Linear layer test: {x.shape} -> {y.shape}")
    
    # اختبار الطبقة الالتفافية
    conv = Co
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)