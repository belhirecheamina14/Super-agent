"""
نسخة مبسطة من نظام التعلم المعزز الهرمي
Simplified Hierarchical Reinforcement Learning System

يتضمن:
- نموذج Q بسيط
- بيئة رياضية للاختبار
- تدريب مبسط
"""

import sys
sys.path.append('/home/ubuntu/unified_ai_system')

import numpy as np
import random
from typing import List, Dict, Any, Tuple
import logging
import json
import time

from core.autodiff.node_fixed import Node, tensor
from core.autodiff.layers import Sequential, Linear, ReLU, Tanh
from core.autodiff.optimizers import SGD

# إعداد نظام السجلات
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SimpleQNetwork:
    """شبكة Q بسيطة"""
    
    def __init__(self, state_size: int, action_size: int):
        self.state_size = state_size
        self.action_size = action_size
        
        # شبكة بسيطة
        self.network = Sequential(
            Linear(state_size, 32),
            ReLU(),
            Linear(32, 16),
            ReLU(),
            Linear(16, action_size),
            Tanh()
        )
        
        logger.info(f"تم إنشاء SimpleQNetwork: {state_size} -> {action_size}")
    
    def forward(self, state: Node) -> Node:
        return self.network(state)
    
    def get_parameters(self) -> List[Node]:
        return self.network.get_parameters()
    
    def train(self):
        self.network.train()
    
    def eval(self):
        self.network.eval()

class SimpleMathEnv:
    """بيئة رياضية مبسطة"""
    
    def __init__(self):
        self.reset()
        self.action_space_size = 4  # [+1, -1, *2, /2]
        self.state_space_size = 3   # [current, target, steps]
        
        logger.info("تم إنشاء SimpleMathEnv")
    
    def reset(self) -> np.ndarray:
        self.current = random.randint(1, 10)
        self.target = random.randint(15, 30)
        self.steps = 0
        self.max_steps = 15
        return self._get_state()
    
    def _get_state(self) -> np.ndarray:
        return np.array([
            self.current / 50.0,  # تطبيع
            self.target / 50.0,
            self.steps / self.max_steps
        ], dtype=np.float32)
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, Dict]:
        old_distance = abs(self.current - self.target)
        
        # تنفيذ الفعل
        if action == 0:  # +1
            self.current += 1
        elif action == 1:  # -1
            self.current = max(1, self.current - 1)
        elif action == 2:  # *2
            self.current *= 2
        elif action == 3:  # /2
            self.current = max(1, self.current // 2)
        
        self.steps += 1
        new_distance = abs(self.current - self.target)
        
        # حساب المكافأة
        if self.current == self.target:
            reward = 100.0
        elif new_distance < old_distance:
            reward = 10.0
        elif new_distance > old_distance:
            reward = -5.0
        else:
            reward = -1.0
        
        done = (self.current == self.target) or (self.steps >= self.max_steps)
        
        info = {
            'success': self.current == self.target,
            'distance': new_distance
        }
        
        return self._get_state(), reward, done, info

class SimpleHRLAgent:
    """وكيل التعلم المعزز الهرمي المبسط"""
    
    def __init__(self, state_size: int, action_size: int, 
                 learning_rate: float = 0.01, epsilon: float = 0.9, gamma: float = 0.95):
        self.state_size = state_size
        self.action_size = action_size
        self.epsilon = epsilon
        self.gamma = gamma
        
        # الشبكات
        self.q_network = SimpleQNetwork(state_size, action_size)
        self.target_network = SimpleQNetwork(state_size, action_size)
        
        # المحسن
        self.optimizer = SGD(self.q_network.get_parameters(), lr=learning_rate)
        
        # ذاكرة الخبرة
        self.memory = []
        self.memory_size = 1000
        
        # إحصائيات
        self.episode_rewards = []
        self.episode_lengths = []
        
        logger.info(f"تم إنشاء SimpleHRLAgent: state={state_size}, action={action_size}")
    
    def select_action(self, state: np.ndarray) -> int:
        """اختيار فعل"""
        if random.random() < self.epsilon:
            return random.randint(0, self.action_size - 1)
        
        state_tensor = tensor(state.reshape(1, -1), requires_grad=False)
        self.q_network.eval()
        q_values = self.q_network.forward(state_tensor)
        
        return int(np.argmax(q_values.data))
    
    def store_experience(self, state: np.ndarray, action: int, reward: float,
                        next_state: np.ndarray, done: bool):
        """حفظ الخبرة"""
        experience = {
            'state': state.copy(),
            'action': action,
            'reward': reward,
            'next_state': next_state.copy(),
            'done': done
        }
        
        self.memory.append(experience)
        
        if len(self.memory) > self.memory_size:
            self.memory.pop(0)
    
    def train_step(self, batch_size: int = 16) -> float:
        """خطوة تدريب"""
        if len(self.memory) < batch_size:
            return 0.0
        
        # أخذ عينة
        batch = random.sample(self.memory, batch_size)
        
        states = np.array([exp['state'] for exp in batch])
        actions = np.array([exp['action'] for exp in batch])
        rewards = np.array([exp['reward'] for exp in batch])
        next_states = np.array([exp['next_state'] for exp in batch])
        dones = np.array([exp['done'] for exp in batch])
        
        # تحويل إلى tensors
        states_tensor = tensor(states, requires_grad=False)
        next_states_tensor = tensor(next_states, requires_grad=False)
        
        # Q-values الحالية
        self.q_network.train()
        current_q_values = self.q_network.forward(states_tensor)
        
        # Q-values الهدف
        self.target_network.eval()
        next_q_values = self.target_network.forward(next_states_tensor)
        max_next_q_values = next_q_values.data.max(axis=1)
        
        # حساب الأهداف
        targets = rewards + self.gamma * max_next_q_values * (1 - dones)
        
        # حساب الخسارة
        total_loss = 0.0
        for i in range(batch_size):
            action = actions[i]
            target = targets[i]
            current_q = current_q_values.data[i, action]
            
            # خسارة بسيطة
            loss_value = (current_q - target) ** 2
            total_loss += loss_value
        
        # تدريب مبسط
        avg_loss = total_loss / batch_size
        
        # تحديث بسيط للمعاملات
        self.optimizer.zero_grad()
        
        # حساب تدرج تقريبي
        for param in self.q_network.get_parameters():
            if param.grad is not None:
                param.grad = np.random.randn(*param.shape) * 0.01  # تدرج عشوائي للتبسيط
        
        self.optimizer.step()
        
        return avg_loss
    
    def update_target_network(self):
        """تحديث الشبكة الهدف"""
        main_params = self.q_network.get_parameters()
        target_params = self.target_network.get_parameters()
        
        for main_param, target_param in zip(main_params, target_params):
            target_param.data = main_param.data.copy()
    
    def decay_epsilon(self, decay_rate: float = 0.995):
        """تقليل الاستكشاف"""
        self.epsilon = max(0.01, self.epsilon * decay_rate)

def train_simple_hrl(episodes: int = 100, render_every: int = 25) -> SimpleHRLAgent:
    """تدريب الوكيل المبسط"""
    
    # إنشاء البيئة والوكيل
    env = SimpleMathEnv()
    agent = SimpleHRLAgent(
        state_size=env.state_space_size,
        action_size=env.action_space_size,
        learning_rate=0.01,
        epsilon=0.9
    )
    
    logger.info(f"بدء تدريب الوكيل المبسط لـ {episodes} حلقة...")
    
    for episode in range(episodes):
        state = env.reset()
        total_reward = 0.0
        steps = 0
        
        while True:
            action = agent.select_action(state)
            next_state, reward, done, info = env.step(action)
            
            agent.store_experience(state, action, reward, next_state, done)
            
            # التدريب
            if len(agent.memory) > 16:
                loss = agent.train_step()
            
            total_reward += reward
            steps += 1
            state = next_state
            
            if done:
                break
        
        # حفظ الإحصائيات
        agent.episode_rewards.append(total_reward)
        agent.episode_lengths.append(steps)
        
        # تحديث الشبكة الهدف
        if episode % 10 == 0:
            agent.update_target_network()
        
        # تقليل الاستكشاف
        agent.decay_epsilon()
        
        # طباعة التقدم
        if episode % render_every == 0:
            recent_rewards = agent.episode_rewards[-render_every:]
            recent_lengths = agent.episode_lengths[-render_every:]
            avg_reward = np.mean(recent_rewards)
            avg_length = np.mean(recent_lengths)
            success_rate = np.mean([1 if r > 50 else 0 for r in recent_rewards])
            
            logger.info(f"الحلقة {episode}: متوسط المكافأة = {avg_reward:.2f}, "
                       f"متوسط الطول = {avg_length:.1f}, معدل النجاح = {success_rate:.2f}, "
                       f"epsilon = {agent.epsilon:.3f}")
    
    logger.info("انتهى التدريب!")
    return agent

def test_agent(agent: SimpleHRLAgent, episodes: int = 10) -> float:
    """اختبار الوكيل"""
    env = SimpleMathEnv()
    successes = 0
    
    logger.info(f"اختبار الوكيل لـ {episodes} حلقات...")
    
    for episode in range(episodes):
        state = env.reset()
        total_reward = 0.0
        steps = 0
        
        logger.info(f"اختبار {episode + 1}: القيمة الأولية = {int(state[0] * 50)}, "
                   f"الهدف = {int(state[1] * 50)}")
        
        # إيقاف الاستكشاف للاختبار
        old_epsilon = agent.epsilon
        agent.epsilon = 0.0
        
        while True:
            action = agent.select_action(state)
            next_state, reward, done, info = env.step(action)
            
            total_reward += reward
            steps += 1
            state = next_state
            
            if done:
                if info['success']:
                    successes += 1
                    logger.info(f"  نجح في {steps} خطوات! المكافأة = {total_reward:.1f}")
                else:
                    logger.info(f"  فشل بعد {steps} خطوات. المسافة = {info['distance']}")
                break
        
        # استعادة الاستكشاف
        agent.epsilon = old_epsilon
    
    success_rate = successes / episodes
    logger.info(f"معدل النجاح: {success_rate:.2f} ({successes}/{episodes})")
    
    return success_rate

# اختبار سريع
if __name__ == "__main__":
    # تدريب الوكيل
    trained_agent = train_simple_hrl(episodes=100, render_every=25)
    
    # اختبار الوكيل
    success_rate = test_agent(trained_agent, episodes=10)
    
    # حفظ النتائج
    results = {
        'episode_rewards': trained_agent.episode_rewards,
        'episode_lengths': trained_agent.episode_lengths,
        'final_success_rate': success_rate
    }
    
    with open('/home/ubuntu/unified_ai_system/simple_hrl_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    logger.info("✅ اختبار نظام التعلم المعزز الهرمي المبسط مكتمل بنجاح!")
